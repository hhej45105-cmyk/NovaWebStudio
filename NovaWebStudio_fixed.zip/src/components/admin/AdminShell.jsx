import { useState } from "react";
import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import {
  ClipboardList,
  LayoutGrid,
  Images,
  MessageSquare,
  Settings,
  LogOut,
  Menu,
  X,
  ExternalLink,
} from "lucide-react";
import Logo from "@/components/site/Logo";
import { useAuth } from "@/lib/AuthContext";
import { useLang } from "@/lib/LanguageContext";

const NAV = [
  { to: "/admin", icon: ClipboardList, ar: "طلبات العملاء", en: "Requests" },
  { to: "/admin/services", icon: LayoutGrid, ar: "الخدمات والأسعار", en: "Services" },
  { to: "/admin/portfolio", icon: Images, ar: "معرض الأعمال", en: "Portfolio" },
  { to: "/admin/messages", icon: MessageSquare, ar: "رسائل الموقع", en: "Messages" },
  { to: "/admin/settings", icon: Settings, ar: "الإعدادات", en: "Settings" },
];

export default function AdminShell({ children }) {
  const { L } = useLang();
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const nav = (
    <nav className="flex flex-col gap-1">
      {NAV.map((item) => {
        const active =
          item.to === "/admin"
            ? location.pathname === "/admin"
            : location.pathname.startsWith(item.to);
        return (
          <Link
            key={item.to}
            to={item.to}
            onClick={() => setOpen(false)}
            className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition ${
              active
                ? "bg-primary/15 text-white ring-1 ring-primary/40"
                : "text-muted-foreground hover:bg-white/5 hover:text-white"
            }`}
          >
            <item.icon className="h-4 w-4" />
            {L(item.ar, item.en)}
          </Link>
        );
      })}
    </nav>
  );

  return (
    <div className="min-h-screen bg-[#04070d] lg:flex">
      <aside className="hidden w-64 shrink-0 flex-col border-e border-white/10 bg-[#060a12] p-5 lg:flex">
        <Logo />
        <div className="mt-8 flex-1">{nav}</div>
        <div className="space-y-2 border-t border-white/10 pt-4">
          <Link
            to="/"
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-xs text-muted-foreground transition hover:text-white"
          >
            <ExternalLink className="h-3.5 w-3.5" />
            {L("عرض الموقع", "View website")}
          </Link>
          <button
            type="button"
            onClick={() => logout()}
            className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs text-muted-foreground transition hover:text-red-400"
          >
            <LogOut className="h-3.5 w-3.5" />
            {L("خروج", "Sign out")}
          </button>
          <p className="px-3 pt-2 text-[11px] text-white/30">{user?.email}</p>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-3 border-b border-white/10 bg-[#060a12]/90 px-4 py-3 backdrop-blur lg:hidden">
          <Logo compact />
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => navigate({ to: "/" })}
              className="rounded-lg border border-white/10 p-2 text-muted-foreground"
              aria-label={L("عرض الموقع", "View website")}
            >
              <ExternalLink className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              className="rounded-lg border border-white/10 p-2 text-white"
              aria-label="Menu"
            >
              {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </header>

        {open && (
          <div className="border-b border-white/10 bg-[#060a12] p-4 lg:hidden">
            {nav}
            <button
              type="button"
              onClick={() => logout()}
              className="mt-3 flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs text-red-400"
            >
              <LogOut className="h-3.5 w-3.5" />
              {L("خروج", "Sign out")}
            </button>
          </div>
        )}

        <div className="flex-1 p-4 sm:p-6 lg:p-8">{children}</div>
      </div>
    </div>
  );
}