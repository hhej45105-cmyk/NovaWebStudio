import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useLang } from "@/lib/LanguageContext";

const EMPTY = {
  title_ar: "",
  title_en: "",
  category_ar: "",
  category_en: "",
  description_ar: "",
  description_en: "",
  image_url: "",
  gallery: [],
  tags_ar: [],
  tags_en: [],
  live_url: "",
  service_slug: "",
  featured: false,
  sort_order: 0,
};

const split = (value) =>
  String(value || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);

export default function ProjectEditor({ project, onSaved }) {
  const { L } = useLang();
  const [form, setForm] = useState({
    ...EMPTY,
    ...(project || {}),
    gallery: (project?.gallery || []).join(", "),
    tags_ar: (project?.tags_ar || []).join(", "),
    tags_en: (project?.tags_en || []).join(", "),
  });
  const [saving, setSaving] = useState(false);
  const set = (key) => (event) =>
    setForm((prev) => ({
      ...prev,
      [key]: event.target.type === "checkbox" ? event.target.checked : event.target.value,
    }));

  const save = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      const payload = {
        ...form,
        gallery: Array.isArray(form.gallery) ? form.gallery : split(form.gallery),
        tags_ar: Array.isArray(form.tags_ar) ? form.tags_ar : split(form.tags_ar),
        tags_en: Array.isArray(form.tags_en) ? form.tags_en : split(form.tags_en),
        sort_order: Number(form.sort_order) || 0,
      };
      delete payload.id;
      delete payload.created_date;
      delete payload.updated_date;
      delete payload.created_by_id;

      if (project?.id) await base44.entities.PortfolioProject.update(project.id, payload);
      else await base44.entities.PortfolioProject.create(payload);
      onSaved();
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={save} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">{L("اسم المشروع", "Title (AR)")}</span>
          <input className="field" value={form.title_ar} onChange={set("title_ar")} required />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">Title (EN)</span>
          <input className="field" dir="ltr" value={form.title_en} onChange={set("title_en")} />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">{L("التصنيف", "Category (AR)")}</span>
          <input className="field" value={form.category_ar} onChange={set("category_ar")} />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">Category (EN)</span>
          <input className="field" dir="ltr" value={form.category_en} onChange={set("category_en")} />
        </label>
      </div>

      <label className="block">
        <span className="mb-1 block text-[11px] font-bold text-white/70">{L("الوصف", "Description (AR)")}</span>
        <textarea className="field min-h-20" value={form.description_ar} onChange={set("description_ar")} />
      </label>
      <label className="block">
        <span className="mb-1 block text-[11px] font-bold text-white/70">Description (EN)</span>
        <textarea className="field min-h-16" dir="ltr" value={form.description_en} onChange={set("description_en")} />
      </label>

      <label className="block">
        <span className="mb-1 block text-[11px] font-bold text-white/70">{L("رابط الصورة الرئيسية", "Cover image URL")}</span>
        <input className="field" dir="ltr" value={form.image_url ?? ""} onChange={set("image_url")} />
      </label>
      <label className="block">
        <span className="mb-1 block text-[11px] font-bold text-white/70">
          {L("صور إضافية (روابط مفصولة بفاصلة)", "Gallery URLs (comma separated)")}
        </span>
        <textarea className="field min-h-16" dir="ltr" value={form.gallery} onChange={set("gallery")} />
      </label>

      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">{L("التقنيات", "Tags (AR)")}</span>
          <input className="field" value={form.tags_ar} onChange={set("tags_ar")} />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">Tags (EN)</span>
          <input className="field" dir="ltr" value={form.tags_en} onChange={set("tags_en")} />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">{L("رابط الموقع", "Live URL")}</span>
          <input className="field" dir="ltr" value={form.live_url ?? ""} onChange={set("live_url")} />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">{L("نوع الخدمة", "Service slug")}</span>
          <input className="field" dir="ltr" value={form.service_slug ?? ""} onChange={set("service_slug")} />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">{L("الترتيب", "Sort order")}</span>
          <input type="number" className="field" value={form.sort_order} onChange={set("sort_order")} />
        </label>
      </div>

      <button type="submit" disabled={saving} className="neon-btn w-full">
        {saving ? L("جارٍ الحفظ...", "Saving...") : L("حفظ المشروع", "Save project")}
      </button>
    </form>
  );
}