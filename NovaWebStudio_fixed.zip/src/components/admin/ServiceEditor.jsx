import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useLang } from "@/lib/LanguageContext";

const EMPTY = {
  slug: "",
  icon: "Monitor",
  title_ar: "",
  title_en: "",
  short_ar: "",
  short_en: "",
  description_ar: "",
  description_en: "",
  features_ar: [],
  features_en: [],
  price_from: "",
  image_url: "",
  sort_order: 0,
  is_active: true,
};

const split = (value) =>
  String(value || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);

export default function ServiceEditor({ service, onSaved }) {
  const { L } = useLang();
  const [form, setForm] = useState({
    ...EMPTY,
    ...(service || {}),
    features_ar: (service?.features_ar || []).join(", "),
    features_en: (service?.features_en || []).join(", "),
  });
  const [saving, setSaving] = useState(false);
  const set = (key) => (event) =>
    setForm((prev) => ({
      ...prev,
      [key]: event.target.type === "checkbox" ? event.target.checked : event.target.value,
    }));

  const save = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      const payload = {
        ...form,
        features_ar: Array.isArray(form.features_ar) ? form.features_ar : split(form.features_ar),
        features_en: Array.isArray(form.features_en) ? form.features_en : split(form.features_en),
        price_from: form.price_from === "" ? null : Number(form.price_from),
        sort_order: Number(form.sort_order) || 0,
      };
      delete payload.id;
      delete payload.created_date;
      delete payload.updated_date;
      delete payload.created_by_id;

      if (service?.id) await base44.entities.Service.update(service.id, payload);
      else await base44.entities.Service.create(payload);
      onSaved();
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={save} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">{L("الرابط (slug)", "Slug")}</span>
          <input className="field" dir="ltr" value={form.slug} onChange={set("slug")} required />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">{L("الأيقونة", "Icon")}</span>
          <input className="field" dir="ltr" value={form.icon} onChange={set("icon")} />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">{L("الاسم بالعربية", "Title (AR)")}</span>
          <input className="field" value={form.title_ar} onChange={set("title_ar")} required />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">{L("الاسم بالإنجليزية", "Title (EN)")}</span>
          <input className="field" dir="ltr" value={form.title_en} onChange={set("title_en")} />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">{L("وصف مختصر", "Short (AR)")}</span>
          <input className="field" value={form.short_ar} onChange={set("short_ar")} />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">{L("وصف مختصر EN", "Short (EN)")}</span>
          <input className="field" dir="ltr" value={form.short_en} onChange={set("short_en")} />
        </label>
      </div>

      <label className="block">
        <span className="mb-1 block text-[11px] font-bold text-white/70">{L("الشرح الكامل", "Description (AR)")}</span>
        <textarea className="field min-h-24" value={form.description_ar} onChange={set("description_ar")} />
      </label>
      <label className="block">
        <span className="mb-1 block text-[11px] font-bold text-white/70">{L("الشرح EN", "Description (EN)")}</span>
        <textarea className="field min-h-20" dir="ltr" value={form.description_en} onChange={set("description_en")} />
      </label>

      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">
            {L("المميزات (مفصولة بفاصلة)", "Features (comma separated)")}
          </span>
          <textarea className="field min-h-20" value={form.features_ar} onChange={set("features_ar")} />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">Features (EN)</span>
          <textarea className="field min-h-20" dir="ltr" value={form.features_en} onChange={set("features_en")} />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">{L("يبدأ من (سعر)", "Starting price")}</span>
          <input type="number" className="field" value={form.price_from ?? ""} onChange={set("price_from")} />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-white/70">{L("الترتيب", "Sort order")}</span>
          <input type="number" className="field" value={form.sort_order} onChange={set("sort_order")} />
        </label>
      </div>

      <label className="block">
        <span className="mb-1 block text-[11px] font-bold text-white/70">{L("رابط الصورة", "Image URL")}</span>
        <input className="field" dir="ltr" value={form.image_url ?? ""} onChange={set("image_url")} />
      </label>

      <label className="flex items-center gap-2 text-xs text-white/80">
        <input type="checkbox" checked={!!form.is_active} onChange={set("is_active")} />
        {L("ظاهر في الموقع", "Visible on the site")}
      </label>

      <button type="submit" disabled={saving} className="neon-btn w-full">
        {saving ? L("جارٍ الحفظ...", "Saving...") : L("حفظ الخدمة", "Save service")}
      </button>
    </form>
  );
}