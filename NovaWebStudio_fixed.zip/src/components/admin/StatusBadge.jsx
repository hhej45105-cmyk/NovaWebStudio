const STYLES = {
  new: "border-sky-500/40 bg-sky-500/15 text-sky-300",
  review: "border-purple-500/40 bg-purple-500/15 text-purple-300",
  in_progress: "border-amber-500/40 bg-amber-500/15 text-amber-300",
  completed: "border-emerald-500/40 bg-emerald-500/15 text-emerald-300",
  rejected: "border-red-500/40 bg-red-500/15 text-red-300",
};

export const STATUS_LABELS = {
  new: { ar: "جديد", en: "New" },
  review: { ar: "قيد المراجعة", en: "In review" },
  in_progress: { ar: "قيد التنفيذ", en: "In progress" },
  completed: { ar: "مكتمل", en: "Completed" },
  rejected: { ar: "مرفوض", en: "Rejected" },
};

export default function StatusBadge({ status, label }) {
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[11px] font-bold ${
        STYLES[status] || "border-white/15 bg-white/5 text-muted-foreground"
      }`}
    >
      {label}
    </span>
  );
}