import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, X, Send } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { assistantReply } from "@/lib/server-fns";
import PromptBar from "@/components/ai/PromptBar";
import { useLang } from "@/lib/LanguageContext";

export default function AssistantChat() {
  const { L, lang } = useLang();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [busy, setBusy] = useState(false);
  const reply = useServerFn(assistantReply);
  const endRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    endRef.current?.scrollIntoView({ block: "end", behavior: "smooth" });
  }, [messages, busy, open]);

  const send = async (text, files) => {
    if (busy) return;
    setBusy(true);
    try {
      const uploaded = [];
      for (const file of files) {
        const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
        uploaded.push({ name: file.name, file_uri });
      }
      const content = text || L("أرفقت ملفات مع طلبي.", "I attached files with my message.");
      const history = messages.slice(-8).map((item) => ({ role: item.role, content: item.content }));
      setMessages((prev) => [...prev, { role: "user", content, files: files.map((file) => file.name) }]);

      const result = await reply({ data: { message: content, history, files: uploaded } });
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: result.reply || L("لم يصل رد، حاول مرة أخرى.", "No reply came back, please retry.") },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: L(
            "تعذّر إرسال رسالتك الآن — حاول مرة أخرى بعد لحظات.",
            "Your message could not be sent right now — please try again in a moment."
          ),
        },
      ]);
    } finally {
      setBusy(false);
    }
  };

  const suggestions = [
    { ar: "ما أنواع المواقع التي تصممونها؟", en: "Which websites do you build?" },
    { ar: "كيف أطلب موقعي؟", en: "How do I order my website?" },
    { ar: "ما طرق الدفع المتاحة؟", en: "What payment methods do you accept?" },
  ];

  return (
    <>
      {open && (
        <div className="rise fixed bottom-24 end-4 z-50 flex h-[min(72vh,560px)] w-[min(92vw,392px)] flex-col overflow-hidden rounded-2xl border border-primary/25 bg-card/95 shadow-2xl backdrop-blur-xl">
          <div className="flex items-center justify-between gap-3 border-b border-white/10 px-4 py-3">
            <div className="flex items-center gap-3">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-primary/15 text-primary ring-1 ring-primary/35">
                <Sparkles className="h-4 w-4" />
              </span>
              <div>
                <p className="text-sm font-bold text-white">{L("مساعد Nova Web Studio", "Nova Web Studio assistant")}</p>
                <p className="text-[11px] text-muted-foreground">
                  {busy ? L("يكتب الآن...", "Typing...") : L("متصل الآن", "Online now")}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label={L("إغلاق", "Close")}
              className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground transition hover:bg-white/10 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="flex-1 space-y-4 overflow-y-auto px-4 py-4">
            {messages.length === 0 && (
              <div className="space-y-4">
                <p className="rounded-2xl bg-secondary/60 px-4 py-3 text-sm leading-7 text-white/85">
                  {L(
                    "أهلاً بك في Nova Web Studio 👋 اسألني عن الخدمات، الأسعار، مدة التنفيذ، أو كيف تبدأ طلب موقعك.",
                    "Welcome to Nova Web Studio 👋 Ask me about services, pricing, timelines, or how to start your website order."
                  )}
                </p>
                <div className="flex flex-col gap-2">
                  {suggestions.map((item) => (
                    <button
                      key={item.en}
                      type="button"
                      onClick={() => send(L(item.ar, item.en), [])}
                      className="flex items-center justify-between gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2 text-start text-xs text-white/80 transition hover:border-primary/40 hover:text-white"
                    >
                      {L(item.ar, item.en)}
                      <Send className="h-3 w-3 shrink-0 text-primary" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((message, index) => (
              <div
                key={`${message.role}-${index}`}
                className={message.role === "user" ? "flex justify-end" : "flex justify-start"}
              >
                <div
                  className={
                    message.role === "user"
                      ? "max-w-[88%] rounded-2xl bg-secondary px-4 py-3 text-sm leading-7 text-white/90"
                      : "max-w-[92%] text-sm leading-7 text-white/85"
                  }
                >
                  <p className="whitespace-pre-line">{message.content}</p>
                  {message.files?.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {message.files.map((name) => (
                        <span
                          key={name}
                          className="max-w-full truncate rounded-full bg-white/10 px-2.5 py-1 text-[10px] text-white/70"
                        >
                          {name}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {busy && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="ai-think">
                  <i />
                  <i />
                  <i />
                </span>
                {L("يفكر...", "Thinking...")}
              </div>
            )}
            <div ref={endRef} />
          </div>

          <div className="border-t border-white/10 p-3">
            <PromptBar onSend={send} busy={busy} />
            <p className="mt-2 text-center text-[10px] text-muted-foreground/80">
              {L("الملفات المرفقة تُخزَّن بشكل خاص.", "Attached files are stored privately.")}
            </p>
          </div>
        </div>
      )}

      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        aria-label={L("مساعد المحادثة", "Chat assistant")}
        className="animate-pulse-glow fixed bottom-5 end-5 z-50 grid h-14 w-14 place-items-center rounded-full bg-primary text-primary-foreground transition hover:scale-105"
      >
        {open ? <X className="h-5 w-5" /> : <Sparkles className="h-5 w-5" />}
      </button>
    </>
  );