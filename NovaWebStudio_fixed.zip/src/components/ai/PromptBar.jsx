import { useEffect, useRef, useState } from "react";
import { Plus, ArrowUp, X, Loader2 } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

export default function PromptBar({ onSend, busy }) {
  const { L, lang } = useLang();
  const [value, setValue] = useState("");
  const [files, setFiles] = useState([]);
  const [hint, setHint] = useState("");
  const textareaRef = useRef(null);
  const fileRef = useRef(null);

  useEffect(() => {
    const text = L(
      "اسألني عن خدماتنا أو ابدأ طلب موقعك...",
      "Ask me about our services or start your website..."
    );
    let index = 0;
    let step = 1;
    let timer;
    const tick = () => {
      index += step;
      setHint(text.slice(0, index));
      if (index >= text.length) {
        step = -1;
        timer = window.setTimeout(tick, 2200);
        return;
      }
      if (index <= 0) {
        step = 1;
        timer = window.setTimeout(tick, 800);
        return;
      }
      timer = window.setTimeout(tick, step > 0 ? 55 : 28);
    };
    setHint("");
    timer = window.setTimeout(tick, 500);
    return () => window.clearTimeout(timer);
  }, [lang, L]);

  const grow = () => {
    const element = textareaRef.current;
    if (!element) return;
    element.style.height = "auto";
    element.style.height = `${Math.min(element.scrollHeight, 112)}px`;
  };

  const submit = () => {
    if (busy) return;
    if (!value.trim() && files.length === 0) return;
    onSend(value.trim(), files);
    setValue("");
    setFiles([]);
    if (textareaRef.current) textareaRef.current.style.height = "auto";
  };

  const handleKeyDown = (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      submit();
    }
  };

  return (
    <div>
      {files.length > 0 && (
        <div className="mb-2 flex flex-wrap gap-2">
          {files.map((file, index) => (
            <span
              key={`${file.name}-${index}`}
              className="inline-flex max-w-full items-center gap-1.5 rounded-full bg-secondary px-3 py-1.5 text-[11px] text-white/80"
            >
              <span className="truncate">{file.name}</span>
              <button
                type="button"
                onClick={() => setFiles((prev) => prev.filter((_, i) => i !== index))}
                aria-label={L("إزالة", "Remove")}
                className="shrink-0 text-muted-foreground transition hover:text-white"
              >
                <X className="h-3 w-3" />
              </button>
            </span>
          ))}
        </div>
      )}

      <div className="ai-ring">
        <div className="rounded-[calc(1.6rem-1px)] bg-card px-4 pb-2.5 pt-3">
          <textarea
            ref={textareaRef}
            rows={1}
            value={value}
            onChange={(event) => {
              setValue(event.target.value);
              grow();
            }}
            onKeyDown={handleKeyDown}
            placeholder={hint}
            aria-label={L("رسالتك", "Message")}
            className="max-h-28 w-full resize-none bg-transparent text-sm leading-6 text-foreground outline-none placeholder:text-muted-foreground/70"
          />

          <div className="mt-2 flex items-end justify-between">
            <input
              ref={fileRef}
              type="file"
              multiple
              className="hidden"
              onChange={(event) => {
                const picked = Array.from(event.target.files || []);
                setFiles((prev) => [...prev, ...picked].slice(0, 3));
                event.target.value = "";
              }}
            />
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              aria-label={L("إرفاق ملف", "Attach file")}
              className="-ms-2 grid h-8 w-8 place-items-center rounded-lg text-muted-foreground transition hover:text-white"
            >
              <Plus className="h-[18px] w-[18px]" strokeWidth={1.9} />
            </button>

            <button
              type="button"
              onClick={submit}
              aria-label={L("إرسال", "Send")}
              className="ai-send grid h-10 w-10 place-items-center rounded-full text-primary transition hover:brightness-125"
            >
              <span className="ai-send-liquid" aria-hidden="true" />
              {busy ? (
                <Loader2 className="relative h-[18px] w-[18px] animate-spin" />
              ) : (
                <ArrowUp className="relative h-[18px] w-[18px]" strokeWidth={1.9} />
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}