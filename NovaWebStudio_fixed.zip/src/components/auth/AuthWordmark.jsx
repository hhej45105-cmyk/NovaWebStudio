// The site name split into single letters, each floating on its own 3D axis.
const LETTERS = ["N", "O", "V", "A", "•", "S", "T", "U", "D", "I", "O"];

export default function AuthWordmark() {
  return (
    <div className="auth-wm" role="img" aria-label="NOVA STUDIO">
      {LETTERS.map((letter, index) => (
        <span
          key={`${letter}-${index}`}
          className={letter === "•" ? "wm-dot" : undefined}
          style={{ animationDelay: `${index * 0.11}s` }}
        >
          {letter}
        </span>
      ))}
    </div>
  );
}