import StatusBadge, { STATUS_LABELS } from "@/components/admin/StatusBadge";
import { useLang } from "@/lib/LanguageContext";

const FLOW = ["new", "review", "in_progress", "completed"];

// Request status shown inside the chat window, so both sides follow progress without leaving it.
export default function ChatStatusBar({ status }) {
  const { L } = useLang();
  const currentIndex = FLOW.indexOf(status);

  return (
    <div className="border-b border-white/10 bg-white/[0.03] px-4 py-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="text-[10px] font-bold uppercase tracking-[0.22em] text-white/40">
          {L("حالة الطلب", "Request status")}
        </span>
        <StatusBadge
          status={status}
          label={L(STATUS_LABELS[status]?.ar || status, STATUS_LABELS[status]?.en || status)}
        />
      </div>

      {status === "rejected" ? (
        <p className="mt-2 text-[11px] leading-5 text-red-300/80">
          {L(
            "تم رفض هذا الطلب. راسلنا في المحادثة لمعرفة السبب أو تعديل التفاصيل.",
            "This request was rejected. Message us here to learn why or adjust the details."
          )}
        </p>
      ) : (
        <div className="mt-3 grid grid-cols-4 gap-1.5">
          {FLOW.map((step, index) => {
            const reached = index <= currentIndex;
            return (
              <div key={step}>
                <div className={`h-1 rounded-full ${reached ? "bg-primary" : "bg-white/10"}`} />
                <p
                  className={`mt-1.5 text-[10px] font-bold ${
                    reached ? "text-white/80" : "text-white/30"
                  }`}
                >
                  {L(STATUS_LABELS[step].ar, STATUS_LABELS[step].en)}
                </p>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}