import { useEffect, useRef, useState } from "react";
import { MessagesSquare, Paperclip, Send, Download, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import ChatStatusBar from "@/components/chat/ChatStatusBar";
import { useAuth } from "@/lib/AuthContext";
import { useLang } from "@/lib/LanguageContext";

const timeOf = (value) =>
  value ? new Date(value).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }) : "";

const initialsOf = (name) =>
  (name || "?").trim().split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase();

export default function ChatThread({ request, mode = "client" }) {
  const { L } = useLang();
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [file, setFile] = useState(null);
  const [sending, setSending] = useState(false);
  const endRef = useRef(null);

  useEffect(() => {
    let active = true;

    const load = async () => {
      const page = await base44.entities.ChatMessage.filter(
        { request_id: request.id },
        { sort: "created_date", limit: 200 }
      );
      if (active) setMessages(page.items || []);
    };
    load();

    const unsubscribe = base44.entities.ChatMessage.subscribe((event) => {
      if (event?.data?.request_id !== request.id || event.type !== "create") return;
      setMessages((prev) =>
        prev.some((item) => item.id === event.data.id) ? prev : [...prev, event.data]
      );
    });

    return () => {
      active = false;
      if (typeof unsubscribe === "function") unsubscribe();
    };
  }, [request.id]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "nearest" });
  }, [messages.length]);

  const send = async (event) => {
    event.preventDefault();
    if ((!text.trim() && !file) || sending) return;
    setSending(true);
    try {
      let attachment_uri = "";
      let attachment_name = "";
      if (file) {
        const uploaded = await base44.integrations.Core.UploadPrivateFile({ file });
        attachment_uri = uploaded.file_uri;
        attachment_name = file.name;
      }
      await base44.entities.ChatMessage.create({
        request_id: request.id,
        client_id: request.created_by_id,
        author_role: mode === "admin" ? "admin" : "client",
        author_name: user?.username || user?.full_name || user?.email || "",
        body: text.trim() || attachment_name,
        attachment_uri,
        attachment_name,
      });
      setText("");
      setFile(null);
    } finally {
      setSending(false);
    }
  };

  const openAttachment = async (uri) => {
    const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri: uri });
    window.open(signed_url, "_blank");
  };

  return (
    <div className="flex h-[560px] flex-col overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02]">
      <div className="flex items-center gap-3 border-b border-white/10 bg-white/[0.03] px-4 py-3">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-primary/30 bg-primary/10 text-primary">
          <MessagesSquare className="h-4 w-4" />
        </span>
        <div className="min-w-0">
          <p className="text-sm font-bold text-white">{L("محادثة المشروع", "Project chat")}</p>
          <p className="truncate font-mono text-[10px] text-muted-foreground">
            {request.order_code} · {request.service_title || request.service_slug}
          </p>
        </div>
      </div>

      <ChatStatusBar status={request.status} />

      <div className="flex-1 space-y-4 overflow-y-auto p-4">
        {messages.length === 0 && (
          <div className="flex h-full flex-col items-center justify-center gap-2 text-center">
            <span className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-white/[0.04] text-primary">
              <MessagesSquare className="h-5 w-5" />
            </span>
            <p className="text-sm font-bold text-white/80">
              {L("لا توجد رسائل بعد", "No messages yet")}
            </p>
            <p className="max-w-xs text-xs leading-5 text-muted-foreground">
              {L(
                "اكتب أول رسالة لتبدأ المتابعة مع فريق Nova Web Studio.",
                "Send the first message to start following up with the Nova Web Studio team."
              )}
            </p>
          </div>
        )}

        {messages.map((message) => {
          const mine =
            mode === "admin" ? message.author_role === "admin" : message.author_role === "client";
          const name =
            message.author_role === "admin"
              ? "Nova Web Studio"
              : message.author_name || request.client_name || "—";

          return (
            <div key={message.id} className={`flex gap-2.5 ${mine ? "flex-row-reverse" : ""}`}>
              <span
                className={`mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full border text-[10px] font-bold ${
                  message.author_role === "admin"
                    ? "border-primary/40 bg-primary/15 text-primary"
                    : "border-white/10 bg-white/[0.06] text-white/70"
                }`}
              >
                {initialsOf(message.author_role === "admin" ? "Nova Studio" : name)}
              </span>

              <div className={`min-w-0 max-w-[80%] ${mine ? "items-end text-end" : ""}`}>
                <div
                  className={`mb-1 flex items-center gap-2 text-[10px] font-bold text-white/40 ${
                    mine ? "justify-end" : ""
                  }`}
                >
                  <span className="uppercase tracking-wider">{name}</span>
                  <span className="font-mono font-normal">{timeOf(message.created_date)}</span>
                </div>
                <div
                  className={`inline-block rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                    mine
                      ? "bg-primary/20 text-white ring-1 ring-primary/30"
                      : "bg-white/[0.06] text-white/85 ring-1 ring-white/10"
                  }`}
                >
                  <p className="whitespace-pre-line break-words">{message.body}</p>
                  {message.attachment_uri && (
                    <button
                      type="button"
                      onClick={() => openAttachment(message.attachment_uri)}
                      className="mt-2 inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-black/20 px-2.5 py-1 text-[11px] font-bold text-primary transition hover:border-primary/50"
                    >
                      <Download className="h-3 w-3" />
                      {message.attachment_name || L("مرفق", "Attachment")}
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>

      <form onSubmit={send} className="border-t border-white/10 bg-white/[0.02] p-3">
        {file && (
          <div className="mb-2 flex items-center justify-between gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-white/80">
            <span className="truncate">{file.name}</span>
            <button
              type="button"
              onClick={() => setFile(null)}
              className="text-muted-foreground transition hover:text-white"
              aria-label={L("إزالة المرفق", "Remove attachment")}
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
        <div className="flex items-center gap-2">
          <label className="grid h-11 w-11 shrink-0 cursor-pointer place-items-center rounded-xl border border-white/10 bg-white/[0.03] text-muted-foreground transition hover:border-primary/40 hover:text-white">
            <Paperclip className="h-4 w-4" />
            <input
              type="file"
              className="hidden"
              onChange={(event) => setFile(event.target.files?.[0] || null)}
            />
          </label>
          <input
            className="field !py-3"
            placeholder={L("اكتب رسالتك...", "Write a message...")}
            value={text}
            onChange={(event) => setText(event.target.value)}
          />
          <button
            type="submit"
            disabled={sending || (!text.trim() && !file)}
            className="neon-btn h-11 !px-4 !py-0 disabled:cursor-not-allowed disabled:opacity-40"
            aria-label={L("إرسال", "Send")}
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
      </form>
    </div>
  );
}