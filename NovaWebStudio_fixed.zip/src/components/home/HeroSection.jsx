import { lazy, Suspense } from "react";
import { ClientOnly, Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, ChevronDown } from "lucide-react";
import { Image } from "@/components/ui/image";
import { useLang } from "@/lib/LanguageContext";

const NeonScene = lazy(() => import("@/components/three/NeonScene"));

const HERO_IMAGE =
  "https://media.base44.com/images/public/6afa065647423eb7533dc7ed/db6f331b6_generated_8a51a490.png";

export default function HeroSection() {
  const { L, dir } = useLang();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;

  return (
    <section
      aria-label={L("مقدمة الوكالة", "Agency introduction")}
      className="relative isolate flex min-h-[92svh] w-full flex-col justify-end overflow-hidden bg-[#03060b] pb-16 pt-28 sm:pb-24"
    >
      <Image
        src={HERO_IMAGE}
        alt=""
        aria-hidden="true"
        fittingType="fill"
        className="pointer-events-none absolute inset-0 -z-20 h-full w-full animate-hero-drift object-cover opacity-75"
      />
      <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(110%_75%_at_50%_115%,hsl(197_100%_50%_/_0.4),transparent_62%)]" />
      <div className="pointer-events-none absolute inset-0 -z-10 bg-gradient-to-b from-[#03060b]/90 via-[#03060b]/55 to-[#03060b]/95" />
      <div className="pointer-events-none absolute inset-0 -z-10 grid-lines opacity-50" />

      <ClientOnly fallback={null}>
        <Suspense fallback={null}>
          <NeonScene className="pointer-events-none absolute inset-0 -z-10 h-full w-full opacity-60" />
        </Suspense>
      </ClientOnly>

      <div className="container-px relative z-10">
        <div className="mx-auto max-w-3xl text-center">
          <p className="rise rise-1 eyebrow">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary" />
            {L("وكالة تصميم وبرمجة مواقع", "WEB DESIGN & DEVELOPMENT AGENCY")}
          </p>

          <h1 className="rise rise-2 mt-6 text-[clamp(2.1rem,6.4vw,4.6rem)] font-extrabold leading-[1.08] text-white">
            {L("أنت تحلم بموقعك،", "You dream your website,")}
            <br />
            <span className="text-gradient">{L("ونحن نصنعه لك", "we build it for you")}</span>
          </h1>

          <p className="rise rise-3 mx-auto mt-6 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            {L(
              "نحوّل أفكارك ومشاريعك إلى مواقع إلكترونية احترافية بتصميم فاخر وتجربة استخدام سريعة، من أول فكرة حتى التسليم.",
              "We turn your ideas into professional websites — luxury design, fast experience, from first idea to final delivery."
            )}
          </p>

          <div className="rise rise-4 mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link to="/order" className="neon-btn w-full sm:w-auto">
              {L("اطلب موقعك الآن", "Request your website")}
              <Arrow className="h-4 w-4" />
            </Link>
            <Link to="/work" className="ghost-btn w-full sm:w-auto">
              {L("شاهد أعمالنا", "View our work")}
            </Link>
          </div>

          <div className="rise rise-4 mt-10 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs font-medium text-muted-foreground">
            <span>12 {L("نوع موقع", "website types")}</span>
            <span className="h-1 w-1 rounded-full bg-primary/60" />
            <span>{L("تسليم احترافي", "Professional delivery")}</span>
            <span className="h-1 w-1 rounded-full bg-primary/60" />
            <span>{L("دعم بعد التسليم", "After-launch support")}</span>
          </div>
        </div>
      </div>

      <ChevronDown className="pointer-events-none absolute bottom-6 left-1/2 hidden h-5 w-5 -translate-x-1/2 animate-float text-primary/70 sm:block" />
    </section>
  );
}