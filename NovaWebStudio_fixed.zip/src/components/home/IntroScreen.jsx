import { lazy, Suspense, useEffect, useState } from "react";
import { ClientOnly } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";
import IntroShapes from "@/components/home/IntroShapes";
import { useLang } from "@/lib/LanguageContext";

const NeonScene = lazy(() => import("@/components/three/NeonScene"));

// Stays true for the rest of this page load, so the gateway is not reshown
// when the visitor navigates back to the home page from inside the site.
let introDismissed = false;

export default function IntroScreen() {
  const { L, dir } = useLang();
  const [phase, setPhase] = useState(introDismissed ? "hidden" : "shown");
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;

  const enter = () => {
    introDismissed = true;
    setPhase("leaving");
    window.setTimeout(() => setPhase("hidden"), 700);
  };

  useEffect(() => {
    document.body.style.overflow = phase === "shown" ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [phase]);

  if (phase === "hidden") return null;

  return (
    <div
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center overflow-hidden bg-[#03060b] transition-opacity duration-700 ${
        phase === "leaving" ? "pointer-events-none opacity-0" : "opacity-100"
      }`}
    >
      <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_50%_at_50%_55%,hsl(197_100%_50%_/_0.22),transparent_70%)]" />

      <ClientOnly fallback={null}>
        <Suspense fallback={null}>
          <NeonScene className="pointer-events-none absolute inset-0 h-full w-full opacity-70" />
        </Suspense>
      </ClientOnly>

      <div className="relative z-10 flex flex-col items-center px-6 text-center">
        <button
          type="button"
          onClick={enter}
          aria-label={L("ادخل إلى الموقع", "Enter the site")}
          className="mb-6 cursor-pointer transition hover:scale-[1.03]"
        >
          <IntroShapes />
        </button>

        <p className="rise rise-1 font-display text-[11px] font-medium uppercase tracking-[0.5em] text-primary">
          {L("وكالة تصميم وبرمجة المواقع", "WEB DESIGN & DEVELOPMENT AGENCY")}
        </p>
        <button type="button" onClick={enter} className="rise rise-2 mt-5 block">
          <h1 className="font-display text-4xl font-bold tracking-[0.12em] text-white transition hover:text-primary sm:text-6xl">
            NOVA<span className="text-primary">•</span>STUDIO
          </h1>
        </button>
        <p className="rise rise-3 mt-5 max-w-md text-sm leading-relaxed text-muted-foreground">
          {L(
            "ندخل الآن إلى عالم من التصميم الفاخر والمواقع التي تُبنى بدقة البكسل.",
            "Entering a world of luxury design and websites built pixel by pixel."
          )}
        </p>

        <button type="button" onClick={enter} className="rise rise-4 neon-btn mt-9 animate-pulse-glow">
          {L("ادخل إلى الموقع", "Enter the site")}
          <Arrow className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}