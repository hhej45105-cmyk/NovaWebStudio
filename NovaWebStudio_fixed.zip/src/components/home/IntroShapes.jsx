import { Code2, Braces, Terminal } from "lucide-react";

const CHIPS = [
  { icon: Code2, className: "left-0 top-6", style: { animationDelay: "0s" } },
  { icon: Braces, className: "right-0 top-24", style: { animationDelay: "1.4s" } },
  { icon: Terminal, className: "left-6 bottom-4", style: { animationDelay: "2.6s" } },
];

export default function IntroShapes() {
  return (
    <div className="px-3d-wrap relative grid h-[240px] w-[240px] place-items-center sm:h-[280px] sm:w-[280px]">
      <div className="px-orbit" />
      <div className="px-orbit px-orbit-2" />

      <div className="px-cube">
        <span />
        <span />
        <span />
        <span />
        <span />
        <span />
      </div>

      <div className="pointer-events-none absolute inset-0 grid place-items-center">
        <span className="font-display text-3xl font-bold text-primary drop-shadow-[0_0_18px_hsl(197_100%_60%_/_0.9)] sm:text-4xl">
          {"</>"}
        </span>
      </div>

      {CHIPS.map(({ icon: Icon, className, style }) => (
        <span
          key={className}
          style={style}
          className={`animate-float absolute grid h-9 w-9 place-items-center rounded-lg border border-primary/35 bg-[#050b14]/80 text-primary shadow-[0_0_24px_-8px_hsl(197_100%_60%_/_0.9)] ${className}`}
        >
          <Icon className="h-4 w-4" />
        </span>
      ))}
    </div>
  );
}