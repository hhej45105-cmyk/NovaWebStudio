import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, ArrowRight, Send } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { notifyNewRequest } from "@/lib/server-fns";
import StepBar from "@/components/order/StepBar";
import StepBasics from "@/components/order/StepBasics";
import StepProject from "@/components/order/StepProject";
import StepAssets from "@/components/order/StepAssets";
import StepPayment from "@/components/order/StepPayment";
import OrderSuccess from "@/components/order/OrderSuccess";
import { useLang } from "@/lib/LanguageContext";

const EMPTY = {
  client_name: "",
  brand_name: "",
  business_type: "",
  service_slug: "",
  idea: "",
  colors: "",
  features: [],
  reference_url: "",
  contact_method: "whatsapp",
  contact_value: "",
  budget: "",
  delivery_date: "",
  logo_uri: "",
  logo_name: "",
  image_uris: [],
  image_names: [],
  payment_method: "",
  payment_reference: "",
  payment_proof_uri: "",
  payment_proof_name: "",
};

export default function OrderForm({ services, initialService = "" }) {
  const { L, dir } = useLang();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({ ...EMPTY, service_slug: initialService });
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState(null);
  const notify = useServerFn(notifyNewRequest);

  const steps = [
    L("بياناتك", "Your details"),
    L("المشروع", "Project"),
    L("الملفات", "Assets"),
    L("الدفع", "Payment"),
  ];
  const set = (key) => (value) =>
    setForm((prev) => ({ ...prev, [key]: value?.target ? value.target.value : value }));
  const setField = (key) => (event) => setForm((prev) => ({ ...prev, [key]: event.target.value }));

  const validate = () => {
    if (step === 0 && (!form.client_name.trim() || !form.contact_value.trim())) {
      return L("يرجى إدخال الاسم وبيانات التواصل.", "Please enter your name and contact details.");
    }
    if (step === 1 && (!form.service_slug || !form.idea.trim())) {
      return L("يرجى اختيار نوع الموقع ووصف الفكرة.", "Please pick a website type and describe your idea.");
    }
    if (
      step === 3 &&
      form.payment_method &&
      form.payment_method !== "later" &&
      !form.payment_reference.trim()
    ) {
      return L(
        "أدخل رقم عملية التحويل، أو اختر «سأدفع عند التواصل».",
        "Enter the transfer reference, or choose “Pay after we talk”."
      );
    }
    return "";
  };

  const next = () => {
    const message = validate();
    if (message) {
      setError(message);
      return;
    }
    setError("");
    setStep((value) => Math.min(value + 1, 3));
  };

  const submit = async () => {
    const message = validate();
    if (message) {
      setError(message);
      return;
    }
    setSending(true);
    setError("");
    try {
      const service = services.find((item) => item.slug === form.service_slug);
      const order_code = `PX-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
      const created = await base44.entities.ServiceRequest.create({
        ...form,
        service_title: service?.title_ar || form.service_slug,
        status: "new",
        order_code,
        payment_status: ["vodafone_cash", "instapay"].includes(form.payment_method)
          ? "pending_review"
          : "unpaid",
      });
      setResult(created);
      notify({ data: { requestId: created.id } }).catch(() => {});
    } catch (submitError) {
      setError(L("تعذّر إرسال الطلب، حاول مرة أخرى.", "Could not submit the request. Please try again."));
    } finally {
      setSending(false);
    }
  };

  if (result) return <OrderSuccess order={result} />;

  return (
    <div className="glass-card p-6 sm:p-8">
      <StepBar steps={steps} current={step} />

      <div className="mt-7">
        {step === 0 && <StepBasics form={form} set={setField} />}
        {step === 1 && <StepProject form={form} set={set} services={services} />}
        {step === 2 && <StepAssets form={form} set={set} />}
        {step === 3 && <StepPayment form={form} set={set} />}
      </div>

      {error && (
        <p className="mt-5 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">
          {error}
        </p>
      )}

      <div className="mt-7 flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => setStep((value) => Math.max(value - 1, 0))}
          disabled={step === 0}
          className="ghost-btn disabled:opacity-40"
        >
          {L("السابق", "Back")}
        </button>

        {step < 3 ? (
          <button type="button" onClick={next} className="neon-btn">
            {L("التالي", "Next")}
            <Arrow className="h-4 w-4" />
          </button>
        ) : (
          <button type="button" onClick={submit} disabled={sending} className="neon-btn">
            <Send className="h-4 w-4" />
            {sending ? L("جارٍ الإرسال...", "Submitting...") : L("إرسال الطلب", "Submit request")}
          </button>
        )}
      </div>
    </div>
  );
}