import { Link } from "@tanstack/react-router";
import { CheckCircle2 } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

export default function OrderSuccess({ order }) {
  const { L } = useLang();

  return (
    <div className="glass-card p-8 text-center">
      <span className="mx-auto grid h-16 w-16 place-items-center rounded-full border border-emerald-500/40 bg-emerald-500/10 text-emerald-400">
        <CheckCircle2 className="h-8 w-8" />
      </span>
      <h2 className="mt-5 text-2xl font-extrabold text-white">
        {L("تم إرسال طلبك بنجاح", "Your request was submitted")}
      </h2>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
        {L(
          "سجلنا طلبك وسنراجعه ونعود إليك على وسيلة التواصل التي اخترتها.",
          "We received your request and will review it, then reach you on your chosen channel."
        )}
      </p>
      <p className="mt-5 inline-block rounded-xl border border-primary/30 bg-primary/10 px-4 py-2 font-mono text-sm text-primary">
        {L("رقم الطلب:", "Order code:")} {order?.order_code}
      </p>
      {["vodafone_cash", "instapay"].includes(order?.payment_method) && (
        <p className="mx-auto mt-4 max-w-md text-xs leading-relaxed text-amber-300/90">
          {L(
            "طلبك بانتظار تأكيد الدفع — سنراجع إثبات التحويل ونبدأ التنفيذ بعد التأكيد.",
            "Your request is awaiting payment confirmation — we will review your proof and start right after."
          )}
        </p>
      )}
      <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
        <Link to="/dashboard" className="neon-btn">
          {L("متابعة الطلب", "Track your request")}
        </Link>
        <Link to="/" className="ghost-btn">
          {L("العودة للرئيسية", "Back home")}
        </Link>
      </div>
    </div>
  );
}