import { useState } from "react";
import { Upload, X, FileImage } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useLang } from "@/lib/LanguageContext";

export default function StepAssets({ form, set }) {
  const { L } = useLang();
  const [busy, setBusy] = useState(false);

  const uploadLogo = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
      set("logo_uri")(file_uri);
      set("logo_name")(file.name);
    } finally {
      setBusy(false);
    }
  };

  const uploadImages = async (event) => {
    const files = Array.from(event.target.files || []);
    if (files.length === 0) return;
    setBusy(true);
    try {
      const uploaded = [];
      for (const file of files) {
        const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
        uploaded.push({ uri: file_uri, name: file.name });
      }
      set("image_uris")([...(form.image_uris || []), ...uploaded.map((item) => item.uri)]);
      set("image_names")([...(form.image_names || []), ...uploaded.map((item) => item.name)]);
    } finally {
      setBusy(false);
    }
  };

  const removeImage = (uri) => {
    set("image_uris")((form.image_uris || []).filter((item) => item !== uri));
    set("image_names")((form.image_names || []).slice(0, (form.image_uris || []).length - 1));
  };

  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs font-bold text-white/80">{L("شعار البراند", "Brand logo")}</p>
        <p className="mt-1 text-[11px] text-muted-foreground">
          {L("PNG أو JPG أو SVG — مخزّن بشكل خاص.", "PNG, JPG or SVG — stored privately.")}
        </p>
        {form.logo_uri ? (
          <div className="mt-3 flex items-center justify-between rounded-xl border border-primary/30 bg-primary/10 px-4 py-3">
            <span className="flex items-center gap-2 text-sm text-white">
              <FileImage className="h-4 w-4 text-primary" />
              {form.logo_name}
            </span>
            <button
              type="button"
              onClick={() => {
                set("logo_uri")("");
                set("logo_name")("");
              }}
              className="text-muted-foreground transition hover:text-red-400"
              aria-label={L("حذف", "Remove")}
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <label className="mt-3 flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-white/20 bg-white/[0.02] px-4 py-8 text-sm text-muted-foreground transition hover:border-primary/50 hover:text-white">
            <Upload className="h-4 w-4" />
            {busy ? L("جارٍ الرفع...", "Uploading...") : L("اختر ملف الشعار", "Choose logo file")}
            <input type="file" accept="image/*" className="hidden" onChange={uploadLogo} disabled={busy} />
          </label>
        )}
      </div>

      <div>
        <p className="text-xs font-bold text-white/80">
          {L("صور المنتجات أو الصور المرجعية", "Product or reference images")}
        </p>
        <p className="mt-1 text-[11px] text-muted-foreground">
          {L("يمكنك رفع عدة صور — مخزّنة بشكل خاص.", "You can upload several images — stored privately.")}
        </p>

        {(form.image_uris || []).length > 0 && (
          <ul className="mt-3 space-y-2">
            {(form.image_uris || []).map((uri, index) => (
              <li
                key={uri}
                className="flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.03] px-4 py-2.5 text-sm text-white/85"
              >
                <span className="flex items-center gap-2 truncate">
                  <FileImage className="h-4 w-4 shrink-0 text-primary" />
                  {form.image_names?.[index] || `image-${index + 1}`}
                </span>
                <button
                  type="button"
                  onClick={() => removeImage(uri)}
                  className="text-muted-foreground transition hover:text-red-400"
                  aria-label={L("حذف", "Remove")}
                >
                  <X className="h-4 w-4" />
                </button>
              </li>
            ))}
          </ul>
        )}

        <label className="mt-3 flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-white/20 bg-white/[0.02] px-4 py-8 text-sm text-muted-foreground transition hover:border-primary/50 hover:text-white">
          <Upload className="h-4 w-4" />
          {busy ? L("جارٍ الرفع...", "Uploading...") : L("أضف صوراً", "Add images")}
          <input type="file" accept="image/*" multiple className="hidden" onChange={uploadImages} disabled={busy} />
        </label>
      </div>
    </div>
  );