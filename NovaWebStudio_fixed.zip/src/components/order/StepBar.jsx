export default function StepBar({ steps, current }) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      {steps.map((step, index) => {
        const active = index === current;
        const done = index < current;
        return (
          <div key={step} className="flex items-center gap-2">
            <span
              className={`grid h-7 w-7 place-items-center rounded-full border text-[11px] font-bold transition ${
                active
                  ? "border-primary bg-primary text-black"
                  : done
                    ? "border-primary/50 bg-primary/15 text-primary"
                    : "border-white/15 text-muted-foreground"
              }`}
            >
              {index + 1}
            </span>
            <span
              className={`text-xs font-semibold ${active ? "text-white" : "text-muted-foreground"}`}
            >
              {step}
            </span>
            {index < steps.length - 1 && <span className="mx-1 h-px w-6 bg-white/15" />}
          </div>
        );
      })}
    </div>
  );
}