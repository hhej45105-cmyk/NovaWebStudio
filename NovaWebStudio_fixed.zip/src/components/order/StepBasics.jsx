import Field from "@/components/order/Field";
import { useLang } from "@/lib/LanguageContext";

const CONTACT_METHODS = [
  { value: "whatsapp", ar: "WhatsApp", en: "WhatsApp" },
  { value: "discord", ar: "Discord", en: "Discord" },
  { value: "email", ar: "بريد إلكتروني", en: "Email" },
  { value: "phone", ar: "مكالمة هاتفية", en: "Phone call" },
];

export default function StepBasics({ form, set }) {
  const { L } = useLang();

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label={L("اسم العميل", "Your name")} required>
          <input className="field" value={form.client_name} onChange={set("client_name")} required />
        </Field>
        <Field label={L("اسم البراند أو المشروع", "Brand / project name")}>
          <input className="field" value={form.brand_name} onChange={set("brand_name")} />
        </Field>
        <Field label={L("نوع النشاط التجاري", "Business type")}>
          <input
            className="field"
            placeholder={L("مثال: متجر ملابس", "e.g. clothing store")}
            value={form.business_type}
            onChange={set("business_type")}
          />
        </Field>
        <Field label={L("وسيلة التواصل", "Preferred contact")}>
          <select className="field" value={form.contact_method} onChange={set("contact_method")}>
            {CONTACT_METHODS.map((method) => (
              <option key={method.value} value={method.value} className="bg-[#0a0f18]">
                {L(method.ar, method.en)}
              </option>
            ))}
          </select>
        </Field>
      </div>

      <Field
        label={L("بيانات التواصل", "Contact details")}
        hint={L(
          "رقم واتساب أو اسم مستخدم Discord أو بريد إلكتروني.",
          "WhatsApp number, Discord username or email address."
        )}
        required
      >
        <input className="field" value={form.contact_value} onChange={set("contact_value")} required />
      </Field>
    </div>
  );
}