import { useEffect, useState } from "react";
import { Upload, FileImage, X, Copy, Wallet } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useLang } from "@/lib/LanguageContext";

const METHODS = [
  { key: "vodafone_cash", ar: "فودافون كاش", en: "Vodafone Cash", field: "vodafone_number" },
  { key: "instapay", ar: "إنستا باي", en: "InstaPay", field: "instapay_handle" },
  { key: "later", ar: "سأدفع عند التواصل", en: "Pay after we talk", field: null },
];

export default function StepPayment({ form, set }) {
  const { L } = useLang();
  const [settings, setSettings] = useState({});
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    base44.entities.SiteConfig.list({ limit: 1 })
      .then((page) => setSettings((page.items || [])[0] || {}))
      .catch(() => setSettings({}));
  }, []);

  const active = METHODS.find((item) => item.key === form.payment_method);
  const target = active?.field ? settings[active.field] : "";

  const uploadProof = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
      set("payment_proof_uri")(file_uri);
      set("payment_proof_name")(file.name);
    } finally {
      setBusy(false);
    }
  };

  const copyTarget = async () => {
    if (!target) return;
    try {
      await navigator.clipboard.writeText(target);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs font-bold text-white/80">{L("طريقة الدفع", "Payment method")}</p>
        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          {METHODS.map((method) => {
            const selected = form.payment_method === method.key;
            return (
              <button
                key={method.key}
                type="button"
                onClick={() => set("payment_method")(method.key)}
                className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-3 text-xs font-bold transition ${
                  selected
                    ? "border-primary/70 bg-primary/15 text-white"
                    : "border-white/12 bg-white/[0.02] text-white/70 hover:border-primary/40 hover:text-white"
                }`}
              >
                <Wallet className="h-4 w-4" />
                {L(method.ar, method.en)}
              </button>
            );
          })}
        </div>
      </div>

      {active?.field && (
        <div className="rounded-xl border border-primary/30 bg-primary/10 p-4">
          <p className="text-[11px] font-bold text-white/70">
            {L("حوّل المبلغ على:", "Send the amount to:")}
          </p>
          {target ? (
            <div className="mt-1.5 flex items-center justify-between gap-3">
              <span className="font-mono text-lg font-bold text-primary" dir="ltr">
                {target}
              </span>
              <button
                type="button"
                onClick={copyTarget}
                className="inline-flex items-center gap-1.5 rounded-lg border border-primary/40 px-2.5 py-1.5 text-[11px] font-bold text-primary transition hover:bg-primary/15"
              >
                <Copy className="h-3 w-3" />
                {copied ? L("تم النسخ", "Copied") : L("نسخ", "Copy")}
              </button>
            </div>
          ) : (
            <p className="mt-1.5 text-xs text-white/70">
              {L(
                "أرسل الطلب وسنرسل لك بيانات التحويل في المحادثة.",
                "Submit the request and we will send you the transfer details in the chat."
              )}
            </p>
          )}
        </div>
      )}

      {form.payment_method && form.payment_method !== "later" && (
        <div className="space-y-4">
          <label className="block">
            <span className="mb-1.5 block text-xs font-bold text-white/80">
              {L("رقم عملية التحويل", "Transfer reference")}
            </span>
            <input
              className="field"
              dir="ltr"
              placeholder="1234567890"
              value={form.payment_reference || ""}
              onChange={(event) => set("payment_reference")(event.target.value)}
            />
          </label>

          <div>
            <p className="text-xs font-bold text-white/80">
              {L("صورة إثبات التحويل", "Transfer screenshot")}
            </p>
            <p className="mt-1 text-[11px] text-muted-foreground">
              {L("اختياري — مخزّنة بشكل خاص.", "Optional — stored privately.")}
            </p>
            {form.payment_proof_uri ? (
              <div className="mt-3 flex items-center justify-between rounded-xl border border-primary/30 bg-primary/10 px-4 py-3">
                <span className="flex items-center gap-2 text-sm text-white">
                  <FileImage className="h-4 w-4 text-primary" />
                  {form.payment_proof_name}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    set("payment_proof_uri")("");
                    set("payment_proof_name")("");
                  }}
                  className="text-muted-foreground transition hover:text-red-400"
                  aria-label={L("حذف", "Remove")}
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <label className="mt-3 flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-white/20 bg-white/[0.02] px-4 py-8 text-sm text-muted-foreground transition hover:border-primary/50 hover:text-white">
                <Upload className="h-4 w-4" />
                {busy ? L("جارٍ الرفع...", "Uploading...") : L("ارفع الصورة", "Upload image")}
                <input type="file" accept="image/*" className="hidden" onChange={uploadProof} disabled={busy} />
              </label>
            )}
          </div>
        </div>
      )}

      <p className="text-[11px] leading-relaxed text-muted-foreground">
        {L(
          "نبدأ التنفيذ بعد تأكيد الدفع من فريقنا.",
          "We start working once our team confirms the payment."
        )}
      </p>
    </div>
  );
}