import Field from "@/components/order/Field";
import { useLang } from "@/lib/LanguageContext";

const FEATURE_OPTIONS = [
  { ar: "سلة شراء ودفع", en: "Cart & checkout" },
  { ar: "نظام حجز مواعيد", en: "Booking system" },
  { ar: "لوحة تحكم", en: "Admin dashboard" },
  { ar: "دفع إلكتروني", en: "Online payments" },
  { ar: "تعدد اللغات", en: "Multi-language" },
  { ar: "مدونة / مقالات", en: "Blog / articles" },
  { ar: "ربط Discord", en: "Discord integration" },
  { ar: "شات مباشر", en: "Live chat" },
  { ar: "تحسين SEO", en: "SEO optimisation" },
  { ar: "معرض أعمال", en: "Portfolio gallery" },
  { ar: "تسجيل دخول العملاء", en: "Customer accounts" },
  { ar: "إشعارات بريدية", en: "Email notifications" },
];

const BUDGETS = [
  { value: "under_200", ar: "أقل من 200$", en: "Under $200" },
  { value: "200_500", ar: "200$ – 500$", en: "$200 – $500" },
  { value: "500_1000", ar: "500$ – 1000$", en: "$500 – $1000" },
  { value: "1000_plus", ar: "أكثر من 1000$", en: "Above $1000" },
  { value: "not_sure", ar: "غير محدد بعد", en: "Not decided yet" },
];

export default function StepProject({ form, set, services }) {
  const { L } = useLang();
  const selectedFeatures = form.features || [];

  const toggleFeature = (label) => {
    set("features")(
      selectedFeatures.includes(label)
        ? selectedFeatures.filter((item) => item !== label)
        : [...selectedFeatures, label]
    );
  };

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label={L("نوع الموقع المطلوب", "Website type")} required>
          <select className="field" value={form.service_slug} onChange={set("service_slug")} required>
            <option value="" className="bg-[#0a0f18]">
              {L("اختر نوع الموقع", "Select a website type")}
            </option>
            {services.map((service) => (
              <option key={service.slug} value={service.slug} className="bg-[#0a0f18]">
                {L(service.title_ar, service.title_en)}
              </option>
            ))}
          </select>
        </Field>
        <Field label={L("الميزانية المتوقعة", "Expected budget")}>
          <select className="field" value={form.budget} onChange={set("budget")}>
            <option value="" className="bg-[#0a0f18]">
              {L("اختر الميزانية", "Select a budget")}
            </option>
            {BUDGETS.map((budget) => (
              <option key={budget.value} value={L(budget.ar, budget.en)} className="bg-[#0a0f18]">
                {L(budget.ar, budget.en)}
              </option>
            ))}
          </select>
        </Field>
        <Field label={L("الألوان المطلوبة", "Preferred colors")}>
          <input
            className="field"
            placeholder={L("مثال: أسود وأزرق نيون", "e.g. black with neon blue")}
            value={form.colors}
            onChange={set("colors")}
          />
        </Field>
        <Field label={L("موعد التسليم المطلوب", "Requested delivery date")}>
          <input
            type="date"
            className="field"
            value={form.delivery_date}
            onChange={set("delivery_date")}
          />
        </Field>
      </div>

      <Field label={L("وصف فكرة الموقع", "Describe your idea")} required>
        <textarea
          className="field min-h-32"
          placeholder={L(
            "اشرح نشاطك، الجمهور المستهدف، والصفحات التي تحتاجها.",
            "Explain your business, target audience and the pages you need."
          )}
          value={form.idea}
          onChange={set("idea")}
          required
        />
      </Field>

      <Field label={L("رابط موقع أو تصميم يعجبك", "A website or design you like")}>
        <input
          className="field"
          dir="ltr"
          placeholder="https://"
          value={form.reference_url}
          onChange={set("reference_url")}
        />
      </Field>

      <div>
        <p className="mb-2 text-xs font-bold text-white/80">
          {L("المميزات التي تريد إضافتها", "Features you want to add")}
        </p>
        <div className="flex flex-wrap gap-2">
          {FEATURE_OPTIONS.map((feature) => {
            const label = L(feature.ar, feature.en);
            const active = selectedFeatures.includes(label);
            return (
              <button
                key={feature.en}
                type="button"
                onClick={() => toggleFeature(label)}
                className={`rounded-full border px-3.5 py-1.5 text-xs font-semibold transition ${
                  active
                    ? "border-primary bg-primary/20 text-white"
                    : "border-white/15 text-muted-foreground hover:border-primary/40 hover:text-white"
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}