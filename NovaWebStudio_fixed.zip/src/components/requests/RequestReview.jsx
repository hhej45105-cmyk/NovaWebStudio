import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { useLang } from "@/lib/LanguageContext";

export default function RequestReview({ request }) {
  const { L } = useLang();
  const { user } = useAuth();
  const [comment, setComment] = useState("");
  const [existing, setExisting] = useState(null);
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    let active = true;
    base44.entities.ClientReview.filter({ request_id: request.id }, { limit: 1 }).then((page) => {
      if (active) setExisting((page.items || [])[0] || null);
    });
    return () => {
      active = false;
    };
  }, [request.id]);

  const submit = async () => {
    setSaving(true);
    const created = await base44.entities.ClientReview.create({
      request_id: request.id,
      client_name: user?.username || user?.full_name || request.client_name,
      project_title: request.brand_name || request.service_title || "",
      comment: comment.trim(),
    });
    setExisting(created);
    setDone(true);
    setSaving(false);
  };

  const shown = existing || (done ? { comment } : null);

  return (
    <div className="glass-card p-6">
      <h2 className="text-sm font-bold text-white">{L("رأيك في التجربة", "Your experience")}</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
        {L(
          "تم تسليم مشروعك. كلمة منك تساعد العملاء الجدد على الثقة بنا.",
          "Your project is delivered. A few words from you help new clients trust us."
        )}
      </p>

      {shown ? (
        <div className="mt-4 rounded-xl border border-white/10 bg-white/[0.02] p-4">
          {shown.comment && <p className="text-sm leading-7 text-white/80">{shown.comment}</p>}
          <p className="mt-2 text-xs font-bold text-emerald-400">
            {L("شكراً لمشاركتك", "Thanks for sharing")}
          </p>
        </div>
      ) : (
        <>
          <textarea
            className="field mt-4 min-h-24"
            value={comment}
            onChange={(event) => setComment(event.target.value)}
            placeholder={L("اكتب رأيك في التصميم والتجربة...", "Tell us about the design and experience...")}
          />
          <button type="button" onClick={submit} disabled={saving} className="neon-btn mt-4">
            {saving ? L("جارٍ الإرسال...", "Sending...") : L("أرسل رأيك", "Send your review")}
          </button>
        </>
      )}
    </div>
  );
}