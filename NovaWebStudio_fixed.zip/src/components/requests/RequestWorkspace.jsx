import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, ArrowLeft, Download, ExternalLink, Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import StatusBadge, { STATUS_LABELS } from "@/components/admin/StatusBadge";
import ChatThread from "@/components/chat/ChatThread";
import RequestReview from "@/components/requests/RequestReview";
import { useLang } from "@/lib/LanguageContext";

const STATUS_ORDER = ["new", "review", "in_progress", "completed", "rejected"];

const PAY_METHOD_LABELS = {
  vodafone_cash: { ar: "فودافون كاش", en: "Vodafone Cash" },
  instapay: { ar: "إنستا باي", en: "InstaPay" },
  later: { ar: "عند التواصل", en: "After we talk" },
};

const PAY_STATUS_LABELS = {
  unpaid: { ar: "غير مدفوع", en: "Unpaid", tone: "border-white/15 text-white/60" },
  pending_review: {
    ar: "بانتظار المراجعة",
    en: "Awaiting review",
    tone: "border-amber-400/40 bg-amber-400/10 text-amber-300",
  },
  paid: {
    ar: "مدفوع",
    en: "Paid",
    tone: "border-emerald-400/40 bg-emerald-400/10 text-emerald-300",
  },
};

const PAY_STATUS_ORDER = ["unpaid", "pending_review", "paid"];

export default function RequestWorkspace({ requestId, mode = "client" }) {
  const { L, dir } = useLang();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;
  const navigate = useNavigate();
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [owner, setOwner] = useState(null);
  const [request, setRequest] = useState(null);
  const [loading, setLoading] = useState(true);
  const [draft, setDraft] = useState({
    status: "new",
    site_url: "",
    admin_notes: "",
    payment_status: "unpaid",
  });
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    let active = true;
    base44.entities.ServiceRequest.get(requestId)
      .then((record) => {
        if (!active) return;
        setRequest(record);
        setDraft({
          status: record.status || "new",
          site_url: record.site_url || "",
          admin_notes: record.admin_notes || "",
          payment_status: record.payment_status || "unpaid",
        });
        setLoading(false);
      })
      .catch(() => {
        if (active) {
          setRequest(null);
          setLoading(false);
        }
      });
    return () => {
      active = false;
    };
  }, [requestId]);

  // Admin only: the account that owns this request (username + email), not the name typed in the form.
  useEffect(() => {
    if (mode !== "admin" || !request?.created_by_id) return;
    let active = true;
    base44.entities.User.get(request.created_by_id)
      .then((user) => {
        if (active) setOwner(user);
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [mode, request?.created_by_id]);

  const saveRequest = async () => {
    const updated = await base44.entities.ServiceRequest.update(request.id, draft);
    setRequest(updated);
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2500);
  };

  const deleteRequest = async () => {
    await base44.entities.ServiceRequest.delete(request.id);
    navigate({ to: "/admin" });
  };

  const openFile = async (uri) => {
    const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri: uri });
    window.open(signed_url, "_blank");
  };

  if (loading) {
    return <p className="py-20 text-center text-sm text-muted-foreground">{L("جارٍ التحميل...", "Loading...")}</p>;
  }

  if (!request) {
    return (
      <div className="glass-card p-10 text-center">
        <p className="text-sm text-muted-foreground">
          {L("لم يتم العثور على هذا الطلب.", "This request was not found.")}
        </p>
        <Link to={mode === "admin" ? "/admin" : "/dashboard"} className="neon-btn mt-5">
          {L("رجوع", "Back")}
        </Link>
      </div>
    );
  }

  const attachments = [...(request.logo_uri ? [{ uri: request.logo_uri, name: L("شعار البراند", "Brand logo") }] : [])];

  return (
    <div className="grid gap-6 lg:grid-cols-[1.25fr_1fr]">
      <div className="space-y-6">
        <div className="glass-card p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-mono text-xs text-primary">{request.order_code}</p>
              <h1 className="mt-1 text-2xl font-extrabold text-white">
                {request.brand_name || request.client_name}
              </h1>
              <p className="mt-1 text-sm text-muted-foreground">
                {request.service_title || request.service_slug}
              </p>
            </div>
            <StatusBadge
              status={request.status}
              label={L(
                STATUS_LABELS[request.status]?.ar || request.status,
                STATUS_LABELS[request.status]?.en || request.status
              )}
            />
          </div>

          {request.site_url && (
            <a
              href={request.site_url}
              target="_blank"
              rel="noreferrer"
              className="mt-4 inline-flex items-center gap-2 rounded-xl border border-primary/30 bg-primary/10 px-4 py-2 text-sm font-bold text-primary"
            >
              <ExternalLink className="h-4 w-4" />
              {L("زيارة موقعك", "Visit your website")}
            </a>
          )}

          <dl className="mt-6 space-y-3 text-sm">
            {[
              [
                mode === "admin" ? L("حساب العميل", "Client account") : L("العميل", "Client"),
                mode === "admin"
                  ? [owner?.username || owner?.full_name, owner?.email].filter(Boolean).join(" · ") ||
                    request.client_name
                  : request.client_name,
              ],
              [L("النشاط", "Business"), request.business_type],
              [L("الميزانية", "Budget"), request.budget],
              [L("موعد التسليم", "Delivery date"), request.delivery_date],
              [L("الألوان", "Colors"), request.colors],
              [L("وسيلة التواصل", "Contact"), `${request.contact_method}: ${request.contact_value}`],
              [L("رابط مرجعي", "Reference"), request.reference_url],
            ]
              .filter(([, value]) => value)
              .map(([label, value]) => (
                <div key={label} className="flex justify-between gap-4 border-b border-white/5 pb-2">
                  <dt className="text-muted-foreground">{label}</dt>
                  <dd className="text-end font-medium text-white/90">{value}</dd>
                </div>
              ))}
          </dl>

          {request.idea && (
            <div className="mt-5">
              <p className="text-xs font-bold text-white/80">{L("فكرة المشروع", "Project idea")}</p>
              <p className="mt-2 whitespace-pre-line text-sm leading-7 text-muted-foreground">
                {request.idea}
              </p>
            </div>
          )}

          {(request.features || []).length > 0 && (
            <div className="mt-5 flex flex-wrap gap-2">
              {request.features.map((feature) => (
                <span
                  key={feature}
                  className="rounded-full border border-white/15 px-3 py-1 text-[11px] text-white/80"
                >
                  {feature}
                </span>
              ))}
            </div>
          )}

          {request.payment_method && (
            <div className="mt-5 rounded-xl border border-white/10 bg-white/[0.02] p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-xs font-bold text-white/80">{L("الدفع", "Payment")}</p>
                <span
                  className={`rounded-full border px-2.5 py-0.5 text-[11px] font-bold ${
                    PAY_STATUS_LABELS[request.payment_status || "unpaid"].tone
                  }`}
                >
                  {L(
                    PAY_STATUS_LABELS[request.payment_status || "unpaid"].ar,
                    PAY_STATUS_LABELS[request.payment_status || "unpaid"].en
                  )}
                </span>
              </div>
              <dl className="mt-3 space-y-2 text-sm">
                <div className="flex justify-between gap-4 border-b border-white/5 pb-2">
                  <dt className="text-muted-foreground">{L("الطريقة", "Method")}</dt>
                  <dd className="text-end font-medium text-white/90">
                    {L(
                      PAY_METHOD_LABELS[request.payment_method]?.ar || request.payment_method,
                      PAY_METHOD_LABELS[request.payment_method]?.en || request.payment_method
                    )}
                  </dd>
                </div>
                {request.payment_reference && (
                  <div className="flex justify-between gap-4 border-b border-white/5 pb-2">
                    <dt className="text-muted-foreground">{L("رقم العملية", "Reference")}</dt>
                    <dd className="text-end font-mono font-medium text-white/90" dir="ltr">
                      {request.payment_reference}
                    </dd>
                  </div>
                )}
              </dl>
              {request.payment_proof_uri && (
                <button
                  type="button"
                  onClick={() => openFile(request.payment_proof_uri)}
                  className="mt-3 inline-flex items-center gap-2 rounded-lg border border-white/15 px-3 py-1.5 text-xs text-primary hover:border-primary/50"
                >
                  <Download className="h-3.5 w-3.5" />
                  {L("إثبات التحويل", "Transfer proof")}
                </button>
              )}
            </div>
          )}

          {attachments.length > 0 && (
            <div className="mt-5">
              <p className="text-xs font-bold text-white/80">{L("الملفات", "Files")}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {attachments.map((file) => (
                  <button
                    key={file.uri}
                    type="button"
                    onClick={() => openFile(file.uri)}
                    className="inline-flex items-center gap-2 rounded-lg border border-white/15 px-3 py-1.5 text-xs text-primary hover:border-primary/50"
                  >
                    <Download className="h-3.5 w-3.5" />
                    {file.name}
                  </button>
                ))}
              </div>
            </div>
          )}

          {(request.image_uris || []).length > 0 && (
            <div className="mt-4">
              <p className="text-xs font-bold text-white/80">{L("صور مرجعية", "Reference images")}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {request.image_uris.map((uri, index) => (
                  <button
                    key={uri}
                    type="button"
                    onClick={() => openFile(uri)}
                    className="inline-flex items-center gap-2 rounded-lg border border-white/15 px-3 py-1.5 text-xs text-primary hover:border-primary/50"
                  >
                    <Download className="h-3.5 w-3.5" />
                    {request.image_names?.[index] || `${index + 1}`}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {mode === "client" && request.status === "completed" && <RequestReview request={request} />}

        {mode === "admin" && (
          <div className="glass-card p-6">
            <h2 className="text-sm font-bold text-white">{L("إدارة الطلب", "Manage request")}</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <label className="block">
                <span className="mb-1.5 block text-xs font-bold text-white/80">
                  {L("حالة الطلب", "Status")}
                </span>
                <select
                  className="field"
                  value={draft.status}
                  onChange={(event) => setDraft((prev) => ({ ...prev, status: event.target.value }))}
                >
                  {STATUS_ORDER.map((status) => (
                    <option key={status} value={status} className="bg-[#0a0f18]">
                      {L(STATUS_LABELS[status].ar, STATUS_LABELS[status].en)}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="mb-1.5 block text-xs font-bold text-white/80">
                  {L("رابط الموقع بعد الانتهاء", "Live website URL")}
                </span>
                <input
                  className="field"
                  dir="ltr"
                  placeholder="https://"
                  value={draft.site_url}
                  onChange={(event) => setDraft((prev) => ({ ...prev, site_url: event.target.value }))}
                />
              </label>
            </div>
            <label className="mt-4 block">
              <span className="mb-1.5 block text-xs font-bold text-white/80">
                {L("حالة الدفع", "Payment status")}
              </span>
              <select
                className="field"
                value={draft.payment_status}
                onChange={(event) => setDraft((prev) => ({ ...prev, payment_status: event.target.value }))}
              >
                {PAY_STATUS_ORDER.map((status) => (
                  <option key={status} value={status} className="bg-[#0a0f18]">
                    {L(PAY_STATUS_LABELS[status].ar, PAY_STATUS_LABELS[status].en)}
                  </option>
                ))}
              </select>
            </label>
            <label className="mt-4 block">
              <span className="mb-1.5 block text-xs font-bold text-white/80">
                {L("ملاحظات داخلية", "Internal notes")}
              </span>
              <textarea
                className="field min-h-24"
                value={draft.admin_notes}
                onChange={(event) => setDraft((prev) => ({ ...prev, admin_notes: event.target.value }))}
              />
            </label>
            <button type="button" onClick={saveRequest} className="neon-btn mt-4">
              {L("حفظ التغييرات", "Save changes")}
              <Arrow className="h-4 w-4" />
            </button>
            {saved && (
              <span className="ms-3 text-xs font-bold text-emerald-400">
                {L("تم الحفظ", "Saved")}
              </span>
            )}

            <div className="mt-6 border-t border-white/10 pt-4">
              {confirmDelete ? (
                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={deleteRequest}
                      className="inline-flex items-center gap-2 rounded-xl border border-red-500/50 bg-red-500/15 px-4 py-2 text-xs font-bold text-red-300 transition hover:bg-red-500/25"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      {L("تأكيد الحذف النهائي", "Confirm permanent delete")}
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDelete(false)}
                      className="text-xs text-muted-foreground transition hover:text-white"
                    >
                      {L("إلغاء", "Cancel")}
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setConfirmDelete(true)}
                    className="inline-flex items-center gap-2 rounded-xl border border-red-500/30 px-4 py-2 text-xs font-bold text-red-300 transition hover:border-red-500/60 hover:bg-red-500/10"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    {L("حذف الطلب", "Delete request")}
                  </button>
              )}
            </div>
          </div>
        )}
      </div>

      <div>
        <ChatThread request={request} mode={mode} />
      </div>
    </div>
  );
}