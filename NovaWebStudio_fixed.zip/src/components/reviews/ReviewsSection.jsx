import { Quote } from "lucide-react";
import SectionHeading from "@/components/site/SectionHeading";
import { useLang } from "@/lib/LanguageContext";

export default function ReviewsSection({ reviews }) {
  const { L } = useLang();
  if (!reviews.length) return null;

  return (
    <section className="border-t border-white/5 py-20">
      <div className="container-px">
        <SectionHeading
          eyebrow={L("آراء العملاء", "Client reviews")}
          title={L("ثقة عملائنا هي أهم أعمالنا", "Our clients' trust is our best work")}
          description={L(
            "كلمات حقيقية من عملاء استلموا مواقعهم من Nova Web Studio.",
            "Real words from clients who received their websites from Nova Web Studio."
          )}
        />

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {reviews.slice(0, 6).map((review) => (
            <div key={review.id} className="glass-card p-6">
              <Quote className="h-6 w-6 text-primary/40" />
              {review.comment && (
                <p className="mt-3 text-sm leading-7 text-muted-foreground">{review.comment}</p>
              )}
              <p className="mt-4 text-sm font-bold text-white">{review.client_name || "—"}</p>
              {review.project_title && (
                <p className="text-[11px] text-primary">{review.project_title}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}