import { Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Image } from "@/components/ui/image";
import ServiceIcon from "@/components/services/serviceIcon";
import { useLang } from "@/lib/LanguageContext";
import { serviceImage } from "@/lib/media";

export default function ServiceCard({ service }) {
  const { L, dir } = useLang();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;
  const image = serviceImage(service);

  return (
    <Link
      to="/services/$slug"
      params={{ slug: service.slug }}
      className="glass-card group flex flex-col overflow-hidden"
    >
      <div className="relative h-44 w-full overflow-hidden bg-[radial-gradient(120%_120%_at_20%_0%,hsl(197_100%_50%_/_0.28),hsl(220_60%_4%_/_0.9))]">
        {image ? (
          <Image
            src={image}
            alt={L(service.title_ar, service.title_en)}
            fittingType="fill"
            onError={(event) => {
              event.currentTarget.style.opacity = "0";
            }}
            className="absolute inset-0 h-44 w-full object-cover transition duration-700 group-hover:scale-105"
          />
        ) : null}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#04070d] via-[#04070d]/40 to-transparent" />
        <span className="absolute bottom-3 start-4 grid h-10 w-10 place-items-center rounded-xl border border-primary/40 bg-[#04070d]/85 text-primary">
          <ServiceIcon name={service.icon} className="h-5 w-5" />
        </span>
      </div>

      <div className="flex flex-1 flex-col p-5">
        <h3 className="text-lg font-bold leading-snug text-white">
          {L(service.title_ar, service.title_en)}
        </h3>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          {L(service.short_ar, service.short_en)}
        </p>
        <div className="mt-auto flex items-center justify-between gap-3 pt-5">
          <span className="text-xs font-semibold text-muted-foreground">
            {typeof service.price_from === "number" && service.price_from > 0
              ? L(`يبدأ من ${service.price_from}$`, `From $${service.price_from}`)
              : L("السعر حسب الطلب", "Priced per project")}
          </span>
          <span className="inline-flex items-center gap-1.5 text-sm font-bold text-primary">
            {L("التفاصيل", "Details")}
            <Arrow className="h-4 w-4 transition group-hover:-translate-x-1 rtl:group-hover:translate-x-1" />
          </span>
        </div>
      </div>
    </Link>
  );
}