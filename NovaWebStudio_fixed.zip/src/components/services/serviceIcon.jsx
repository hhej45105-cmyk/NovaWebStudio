import {
  Shirt,
  UtensilsCrossed,
  MessagesSquare,
  PackageCheck,
  Server,
  Gamepad2,
  Building2,
  Sparkles,
  Cpu,
  Palette,
  Home,
  CalendarCheck,
  Monitor,
} from "lucide-react";

const ICONS = {
  Shirt,
  UtensilsCrossed,
  MessagesSquare,
  PackageCheck,
  Server,
  Gamepad2,
  Building2,
  Sparkles,
  Cpu,
  Palette,
  Home,
  CalendarCheck,
  Monitor,
};

export default function ServiceIcon({ name, className = "h-6 w-6" }) {
  const Icon = ICONS[name] || Monitor;
  return <Icon className={className} strokeWidth={1.6} />;
}