import { useState } from "react";
import { Music, Pause } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

const VIDEO_ID = "tntu_zHVCdI";

export default function AmbientMusic() {
  const { L } = useLang();
  const [playing, setPlaying] = useState(false);

  return (
    <>
      {playing && (
        <iframe
          key="nova-music"
          title="Nova Web Studio soundtrack"
          src={`https://www.youtube-nocookie.com/embed/${VIDEO_ID}?autoplay=1&loop=1&playlist=${VIDEO_ID}&controls=0&modestbranding=1&playsinline=1`}
          allow="autoplay; encrypted-media"
          aria-hidden="true"
          tabIndex={-1}
          className="pointer-events-none fixed bottom-0 start-0 z-0 h-1 w-1 border-0 opacity-0"
        />
      )}

      <button
        type="button"
        onClick={() => setPlaying((prev) => !prev)}
        aria-pressed={playing}
        aria-label={L("موسيقى هادئة", "Music")}
        className={`glass fixed bottom-5 start-5 z-40 inline-flex items-center gap-2 rounded-full px-4 py-3 text-xs font-bold transition hover:border-primary/60 ${
          playing ? "text-primary" : "text-white/75"
        }`}
      >
        {playing ? <Pause className="h-4 w-4" /> : <Music className="h-4 w-4" />}
        <span className="hidden sm:inline">{playing ? L("إيقاف الموسيقى", "Stop music") : L("تشغيل الموسيقى", "Play music")}</span>
      </button>
    </>
  );
}