import { Link } from "@tanstack/react-router";
import { Image } from "@/components/ui/image";
import { LOGO_URL } from "@/lib/brand";

export default function Logo({ compact = false }) {
  return (
    <Link to="/" className="group inline-flex items-center gap-2.5">
      <span className="relative h-11 w-11 shrink-0 overflow-hidden rounded-lg border border-primary/40 bg-[#050505] shadow-[0_0_24px_-6px_hsl(197_100%_55%_/_0.8)]">
        <Image
          src={LOGO_URL}
          alt="Nova Web Studio"
          fittingType="fill"
          focalPointX={0.5}
          focalPointY={0.24}
          className="h-full w-full"
        />
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="font-display text-[15px] font-bold tracking-[0.18em] text-white">
            NOVA<span className="text-primary">•</span>STUDIO
          </span>
          <span className="mt-1 text-[10px] font-medium tracking-[0.22em] text-muted-foreground">
            WEB DESIGN &amp; CODE
          </span>
        </span>
      )}
    </Link>
  );
}