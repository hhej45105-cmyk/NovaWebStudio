export default function SectionHeading({ eyebrow, title, description, center = true, action }) {
  return (
    <div
      className={`flex flex-col gap-4 ${center ? "items-center text-center" : "items-start text-start"} ${
        action ? "md:flex-row md:items-end md:justify-between md:text-start" : ""
      }`}
    >
      <div className={center && !action ? "max-w-2xl" : "max-w-2xl"}>
        {eyebrow && <span className="eyebrow">{eyebrow}</span>}
        <h2 className="mt-4 text-3xl font-extrabold leading-tight text-white sm:text-4xl">{title}</h2>
        {description && (
          <p className="mt-3 text-base leading-relaxed text-muted-foreground">{description}</p>
        )}
      </div>
      {action}
    </div>
  );
}