import { Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, MessagesSquare } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

const PAGES = [
  { to: "/services", ar: "خدماتنا", en: "Services" },
  { to: "/work", ar: "أعمالنا", en: "Work" },
  { to: "/about", ar: "من نحن", en: "About" },
  { to: "/faq", ar: "الأسئلة الشائعة", en: "FAQ" },
  { to: "/contact", ar: "تواصل معنا", en: "Contact" },
];

export default function SiteFooter() {
  const { L, dir } = useLang();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;

  return (
    <footer className="relative overflow-hidden border-t border-white/10 bg-[#04070d]">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-64 bg-[radial-gradient(60%_100%_at_50%_0%,hsl(197_100%_50%_/_0.16),transparent)]" />
      <div className="container-px relative py-16">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <div className="font-display text-2xl font-bold tracking-[0.16em] text-white">
              NOVA<span className="text-primary">•</span>STUDIO
            </div>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
              {L(
                "وكالة متخصصة في تصميم وبرمجة المواقع الإلكترونية. نحوّل فكرتك إلى موقع احترافي متكامل وجاهز للنمو.",
                "An agency specialised in web design and development. We turn your idea into a polished, ready-to-grow website."
              )}
            </p>
            <Link to="/order" className="neon-btn mt-6">
              {L("اطلب موقعك الآن", "Start your project")}
              <Arrow className="h-4 w-4" />
            </Link>
            <a
              href="https://discord.gg/CjQS82TEwE"
              target="_blank"
              rel="noreferrer"
              className="mt-3 flex w-fit items-center gap-2 rounded-xl border border-primary/35 bg-primary/10 px-5 py-3 text-sm font-bold text-primary transition hover:bg-primary/20"
            >
              <MessagesSquare className="h-4 w-4" />
              {L("انضم لسرفر الدسكورد", "Join our Discord server")}
            </a>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-[0.24em] text-primary">
              {L("الصفحات", "Pages")}
            </h4>
            <ul className="mt-4 space-y-2.5">
              {PAGES.map((p) => (
                <li key={p.to}>
                  <Link
                    to={p.to}
                    className="text-sm text-muted-foreground transition hover:text-white"
                  >
                    {L(p.ar, p.en)}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-[0.24em] text-primary">
              {L("ابدأ الآن", "Get started")}
            </h4>
            <ul className="mt-4 space-y-2.5 text-sm text-muted-foreground">
              <li>
                <Link to="/order" className="transition hover:text-white">
                  {L("اطلب موقعك", "Request a website")}
                </Link>
              </li>
              <li>
                <Link to="/contact" className="transition hover:text-white">
                  {L("تواصل معنا", "Contact us")}
                </Link>
              </li>
              <li>
                <Link to="/login" className="transition hover:text-white">
                  {L("تسجيل دخول العملاء", "Client sign in")}
                </Link>
                <Link to="/register" className="mt-2.5 block transition hover:text-white">
                  {L("إنشاء حساب جديد", "Create an account")}
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-6 text-xs text-muted-foreground sm:flex-row">
          <span>© {2026} Nova Web Studio — {L("جميع الحقوق محفوظة", "All rights reserved")}</span>
          <span className="font-display tracking-[0.28em] text-white/30">
            {L("صُمم وبُرمج بعناية", "DESIGNED &amp; BUILT WITH CARE")}
          </span>
        </div>
      </div>
    </footer>
  );
}