import { useEffect, useState } from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { Menu, X, Globe, User, LayoutDashboard } from "lucide-react";
import Logo from "@/components/site/Logo";
import { useAuth } from "@/lib/AuthContext";
import { useLang } from "@/lib/LanguageContext";

const NAV = [
  { to: "/", ar: "الرئيسية", en: "Home" },
  { to: "/services", ar: "خدماتنا", en: "Services" },
  { to: "/work", ar: "أعمالنا", en: "Work" },
  { to: "/about", ar: "من نحن", en: "About" },
  { to: "/faq", ar: "الأسئلة", en: "FAQ" },
  { to: "/contact", ar: "تواصل", en: "Contact" },
];

export default function SiteHeader() {
  const { lang, setLang, L } = useLang();
  const { user } = useAuth();
  const { pathname } = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const isActive = (to) => (to === "/" ? pathname === "/" : pathname.startsWith(to));

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-500 ${
        scrolled ? "border-b border-primary/15 bg-[#04070d]/85 backdrop-blur-xl" : "bg-transparent"
      }`}
    >
      <div className="container-px flex h-[72px] items-center justify-between gap-4">
        <Logo />

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={`rounded-lg px-3 py-2 text-sm font-medium transition hover:bg-white/5 hover:text-white ${
                isActive(item.to) ? "bg-white/5 text-white" : "text-muted-foreground"
              }`}
            >
              {L(item.ar, item.en)}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setLang(lang === "ar" ? "en" : "ar")}
            className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 px-2.5 py-2 text-xs font-bold text-muted-foreground transition hover:border-primary/40 hover:text-white"
            aria-label="Switch language"
          >
            <Globe className="h-3.5 w-3.5" />
            {lang === "ar" ? "EN" : "ع"}
          </button>
          {user?.role === "admin" && (
            <Link
              to="/admin"
              className="grid h-10 w-10 place-items-center rounded-lg border border-primary/30 text-primary transition hover:border-primary/60 hover:text-white"
              aria-label={L("لوحة التحكم", "Dashboard")}
            >
              <LayoutDashboard className="h-4 w-4" />
            </Link>
          )}
          {user ? (
            <Link
              to="/dashboard"
              className="grid h-10 w-10 place-items-center rounded-lg border border-white/10 text-muted-foreground transition hover:border-primary/40 hover:text-white"
              aria-label={L("حسابي", "My account")}
            >
              <User className="h-4 w-4" />
            </Link>
          ) : (
            <Link to="/login" className="ghost-btn hidden !px-4 !py-2.5 !text-xs sm:inline-flex">
              {L("تسجيل الدخول", "Sign in")}
            </Link>
          )}
          <Link to="/order" className="neon-btn hidden !px-5 !py-2.5 sm:inline-flex">
            {L("اطلب موقعك", "Start a project")}
          </Link>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="grid h-10 w-10 place-items-center rounded-lg border border-white/10 text-white lg:hidden"
            aria-label="Menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-white/10 bg-[#04070d]/95 backdrop-blur-xl lg:hidden">
          <div className="container-px flex flex-col gap-1 py-4">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className={`rounded-lg px-3 py-2.5 text-sm font-medium transition hover:bg-white/5 hover:text-white ${
                  isActive(item.to) ? "bg-white/5 text-white" : "text-muted-foreground"
                }`}
              >
                {L(item.ar, item.en)}
              </Link>
            ))}
            <Link to="/order" onClick={() => setOpen(false)} className="neon-btn mt-2 w-full">
              {L("اطلب موقعك الآن", "Start your project")}
            </Link>
            {user?.role === "admin" && (
              <Link to="/admin" onClick={() => setOpen(false)} className="ghost-btn mt-2 w-full">
                <LayoutDashboard className="h-4 w-4" />
                {L("لوحة التحكم", "Dashboard")}
              </Link>
            )}
            {user ? (
              <Link to="/dashboard" onClick={() => setOpen(false)} className="ghost-btn mt-2 w-full">
                {L("حسابي وطلباتي", "My account & requests")}
              </Link>
            ) : (
              <Link to="/login" onClick={() => setOpen(false)} className="ghost-btn mt-2 w-full">
                {L("تسجيل الدخول", "Sign in")}
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
}