import { lazy, Suspense } from "react";
import { ClientOnly } from "@tanstack/react-router";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import AssistantChat from "@/components/ai/AssistantChat";
import AmbientMusic from "@/components/site/AmbientMusic";

const SiteBackground = lazy(() => import("@/components/three/SiteBackground"));

export default function SiteLayout({ children, withFooter = true }) {
  return (
    <div className="relative min-h-screen">
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <ClientOnly fallback={null}>
          <Suspense fallback={null}>
            <SiteBackground className="h-full w-full" />
          </Suspense>
        </ClientOnly>
      </div>

      <div className="relative z-10 flex min-h-screen flex-col">
        <SiteHeader />
        <main className="flex-1">{children}</main>
        {withFooter && <SiteFooter />}
      </div>

      <AssistantChat />
      <AmbientMusic />
    </div>
  );
}