import { useEffect, useRef } from "react";
import * as THREE from "three";

export default function NeonScene({ className = "" }) {
  const hostRef = useRef(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    let renderer;
    try {
      renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    } catch (err) {
      return;
    }

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 120);
    camera.position.set(0, 0, 7.5);

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setClearColor(0x000000, 0);
    renderer.domElement.style.display = "block";
    host.appendChild(renderer.domElement);

    const shards = new THREE.Group();
    const shardGeo = new THREE.IcosahedronGeometry(1.5, 0);
    for (let i = 0; i < 8; i++) {
      const mesh = new THREE.Mesh(
        shardGeo,
        new THREE.MeshBasicMaterial({
          color: i % 2 === 0 ? 0x1fa3ff : 0x8be9ff,
          wireframe: true,
          transparent: true,
          opacity: 0.3 + Math.random() * 0.25,
        })
      );
      mesh.position.set((Math.random() - 0.5) * 7, (Math.random() - 0.5) * 4, (Math.random() - 0.5) * 4);
      mesh.rotation.set(Math.random() * 3, Math.random() * 3, Math.random() * 3);
      mesh.scale.setScalar(0.24 + Math.random() * 0.75);
      shards.add(mesh);
    }
    scene.add(shards);

    const count = 900;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 18;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 11;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 12;
    }
    const pointsGeo = new THREE.BufferGeometry();
    pointsGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const points = new THREE.Points(
      pointsGeo,
      new THREE.PointsMaterial({ color: 0x6fd8ff, size: 0.035, transparent: true, opacity: 0.75 })
    );
    scene.add(points);

    const resize = () => {
      const w = host.clientWidth || 1;
      const h = host.clientHeight || 1;
      renderer.setSize(w, h, false);
      renderer.domElement.style.width = "100%";
      renderer.domElement.style.height = "100%";
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();

    const observer = new ResizeObserver(resize);
    observer.observe(host);

    const clock = new THREE.Clock();
    let frame = 0;
    const loop = () => {
      const t = clock.getElapsedTime();
      shards.rotation.y = t * 0.16;
      shards.rotation.x = Math.sin(t * 0.24) * 0.16;
      shards.children.forEach((mesh, i) => {
        mesh.rotation.x += 0.002 + i * 0.0002;
        mesh.rotation.y += 0.0026;
      });
      points.rotation.y = -t * 0.035;
      renderer.render(scene, camera);
      frame = requestAnimationFrame(loop);
    };
    loop();

    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      pointsGeo.dispose();
      shardGeo.dispose();
      scene.traverse((obj) => {
        if (obj.material) obj.material.dispose();
      });
      renderer.dispose();
      if (renderer.domElement.parentNode === host) host.removeChild(renderer.domElement);
    };
  }, []);

  return <div ref={hostRef} aria-hidden="true" className={className} />;
}