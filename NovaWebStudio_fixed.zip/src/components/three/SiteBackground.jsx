import { useEffect, useRef } from "react";
import * as THREE from "three";

const COLORS = [0x35b6ff, 0x8be9ff, 0x5f8dff, 0x35b6ff];

export default function SiteBackground({ className = "" }) {
  const hostRef = useRef(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    let renderer;
    try {
      renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    } catch (err) {
      return;
    }

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(55, 1, 0.1, 200);
    camera.position.set(0, 0, 13);

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.setClearColor(0x000000, 0);
    renderer.domElement.style.display = "block";
    host.appendChild(renderer.domElement);

    const geometries = [
      new THREE.IcosahedronGeometry(1.6, 0),
      new THREE.TorusKnotGeometry(1, 0.32, 90, 12),
      new THREE.OctahedronGeometry(1.5, 0),
      new THREE.DodecahedronGeometry(1.35, 0),
      new THREE.TorusGeometry(1.6, 0.1, 12, 56),
      new THREE.BoxGeometry(1.7, 1.7, 1.7),
      new THREE.ConeGeometry(1.15, 2, 6),
      new THREE.IcosahedronGeometry(1.2, 1),
    ];

    const field = new THREE.Group();
    scene.add(field);

    const shapes = [];
    const place = [
      [-6.2, 2.4, -1],
      [6.4, -1.2, -2.5],
      [-5.4, -5.6, -0.5],
      [5.2, 5.2, -3.5],
      [0.4, 8.4, -4.5],
      [-7.4, 9.6, -2],
      [7.6, 9.2, -1.5],
      [2.6, -9.4, -2.5],
    ];

    geometries.forEach((geometry, index) => {
      const [x, y, z] = place[index] || [0, 0, 0];
      const wire = new THREE.Mesh(
        geometry,
        new THREE.MeshBasicMaterial({
          color: COLORS[index % COLORS.length],
          wireframe: index % 2 === 0,
          transparent: true,
          opacity: index % 2 === 0 ? 0.3 : 0.16,
        })
      );
      wire.position.set(x, y, z);
      wire.rotation.set(Math.random() * 3, Math.random() * 3, Math.random() * 3);
      wire.scale.setScalar(0.8 + Math.random() * 0.7);
      field.add(wire);
      shapes.push({
        mesh: wire,
        baseY: y,
        speed: 0.4 + Math.random() * 0.5,
        spin: { x: 0.0012 + Math.random() * 0.0016, y: 0.0016 + Math.random() * 0.002 },
      });
    });

    const count = 320;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 30;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 34;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 18;
    }
    const pointsGeo = new THREE.BufferGeometry();
    pointsGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const points = new THREE.Points(
      pointsGeo,
      new THREE.PointsMaterial({ color: 0x7fdcff, size: 0.055, transparent: true, opacity: 0.55 })
    );
    scene.add(points);

    const resize = () => {
      const width = host.clientWidth || 1;
      const height = host.clientHeight || 1;
      renderer.setSize(width, height, false);
      renderer.domElement.style.width = "100%";
      renderer.domElement.style.height = "100%";
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    };
    resize();

    const observer = new ResizeObserver(resize);
    observer.observe(host);

    const reduceMotion =
      typeof window.matchMedia === "function" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const pointer = { x: 0, y: 0 };
    let scrolled = window.scrollY;
    let targetScroll = scrolled;
    const onScroll = () => {
      targetScroll = window.scrollY;
    };
    const onPointerMove = (event) => {
      pointer.x = event.clientX / window.innerWidth - 0.5;
      pointer.y = event.clientY / window.innerHeight - 0.5;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("pointermove", onPointerMove, { passive: true });

    let frame = 0;
    const clock = new THREE.Clock();

    const renderFrame = () => {
      renderer.render(scene, camera);
    };

    const loop = () => {
      const time = clock.getElapsedTime();
      scrolled += (targetScroll - scrolled) * 0.07;
      camera.position.y = -(scrolled / Math.max(window.innerHeight, 1)) * 3.4;
      camera.position.x += (pointer.x * 1.4 - camera.position.x) * 0.045;
      camera.lookAt(0, camera.position.y, 0);

      field.rotation.y = time * 0.025;
      shapes.forEach((item, index) => {
        item.mesh.rotation.x += item.spin.x;
        item.mesh.rotation.y += item.spin.y;
        item.mesh.position.y = item.baseY + Math.sin(time * item.speed + index) * 0.4;
      });
      points.rotation.y = -time * 0.012;

      renderer.render(scene, camera);
      frame = requestAnimationFrame(loop);
    };

    if (reduceMotion) {
      renderFrame();
    } else {
      loop();
    }

    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("pointermove", onPointerMove);
      observer.disconnect();
      pointsGeo.dispose();
      geometries.forEach((geometry) => geometry.dispose());
      scene.traverse((object) => {
        if (object.material) object.material.dispose();
      });
      renderer.dispose();
      if (renderer.domElement.parentNode === host) host.removeChild(renderer.domElement);
    };
  }, []);

  return <div ref={hostRef} aria-hidden="true" className={className} />;