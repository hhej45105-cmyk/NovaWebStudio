import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { Image } from "@/components/ui/image";
import { useLang } from "@/lib/LanguageContext";
import { projectImage } from "@/lib/media";

export default function ProjectCard({ project }) {
  const { L } = useLang();

  return (
    <Link
      to="/work/$projectId"
      params={{ projectId: project.id }}
      className="glass-card group relative overflow-hidden"
    >
      <div className="relative h-56 w-full overflow-hidden bg-[radial-gradient(120%_120%_at_80%_0%,hsl(197_100%_50%_/_0.3),hsl(220_60%_4%_/_0.92))] sm:h-64">
        <Image
          src={projectImage(project)}
          alt={L(project.title_ar, project.title_en)}
          fittingType="fill"
          onError={(event) => {
            event.currentTarget.style.opacity = "0";
          }}
          className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-105"
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#04070d] via-[#04070d]/35 to-transparent" />
        <span className="absolute end-4 top-4 rounded-full border border-white/15 bg-black/50 px-3 py-1 text-[11px] font-bold text-white backdrop-blur">
          {L(project.category_ar, project.category_en)}
        </span>
      </div>
      <div className="flex items-center justify-between gap-3 p-5">
        <div>
          <h3 className="font-bold text-white">{L(project.title_ar, project.title_en)}</h3>
          <p className="mt-1 line-clamp-1 text-xs text-muted-foreground">
            {L(project.description_ar, project.description_en)}
          </p>
        </div>
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-primary/40 text-primary transition group-hover:bg-primary group-hover:text-black">
          <ArrowUpRight className="h-4 w-4" />
        </span>
      </div>
    </Link>
  );
}