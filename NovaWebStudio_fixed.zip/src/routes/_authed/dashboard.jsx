import { useEffect, useState } from "react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, LogOut, Plus, LayoutDashboard } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import StatusBadge, { STATUS_LABELS } from "@/components/admin/StatusBadge";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/_authed/dashboard")({
  head: () => ({ meta: [{ title: "حسابي — Nova Web Studio" }] }),
  component: DashboardPage,
});

function DashboardPage() {
  const { L, dir } = useLang();
  const { user, logout } = useAuth();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    base44.entities.ServiceRequest.filter({}, { sort: "-created_date", limit: 50 })
      .then((page) => {
        if (active) {
          setRequests(page.items || []);
          setLoading(false);
        }
      })
      .catch(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, []);

  return (
    <section className="py-14">
      <div className="container-px mx-auto max-w-4xl">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <span className="eyebrow">{L("حسابي", "My account")}</span>
            <h1 className="mt-4 text-3xl font-extrabold text-white">
              {L("طلباتي", "My requests")}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {user?.username ? `${user.username} · ${user.email}` : user?.email}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {user?.role === "admin" && (
              <Link to="/admin" className="ghost-btn">
                <LayoutDashboard className="h-4 w-4" />
                {L("لوحة التحكم", "Dashboard")}
              </Link>
            )}
            <Link to="/order" className="neon-btn">
              <Plus className="h-4 w-4" />
              {L("طلب موقع جديد", "New website request")}
            </Link>
            <button type="button" onClick={() => logout()} className="ghost-btn">
              <LogOut className="h-4 w-4" />
              {L("تسجيل الخروج", "Sign out")}
            </button>
          </div>
        </div>

        <div className="mt-8 space-y-3">
          {loading && <p className="text-sm text-muted-foreground">{L("جارٍ التحميل...", "Loading...")}</p>}

          {!loading && requests.length === 0 && (
            <div className="glass-card p-10 text-center">
              <p className="text-sm text-muted-foreground">
                {L("لم ترسل أي طلب بعد.", "You haven't submitted a request yet.")}
              </p>
              <Link to="/order" className="neon-btn mt-5">
                {L("اطلب موقعك الآن", "Start your request")}
              </Link>
            </div>
          )}

          {requests.map((request) => (
            <Link
              key={request.id}
              to="/requests/$requestId"
              params={{ requestId: request.id }}
              className="glass-card flex flex-wrap items-center justify-between gap-4 p-5"
            >
              <div>
                <p className="font-mono text-[11px] text-primary">{request.order_code}</p>
                <p className="mt-1 font-bold text-white">
                  {request.brand_name || request.service_title || request.client_name}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {request.service_title} ·{" "}
                  {request.created_date
                    ? new Date(request.created_date).toLocaleDateString("en-GB")
                    : ""}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <StatusBadge
                  status={request.status}
                  label={L(
                    STATUS_LABELS[request.status]?.ar || request.status,
                    STATUS_LABELS[request.status]?.en || request.status
                  )}
                />
                <Arrow className="h-4 w-4 text-muted-foreground" />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}