import { createFileRoute } from "@tanstack/react-router";
import { listServices } from "@/lib/server-fns";
import OrderForm from "@/components/order/OrderForm";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/_authed/order")({
  validateSearch: (search) => ({
    service: typeof search.service === "string" ? search.service : "",
  }),
  loader: () => listServices(),
  head: () => ({ meta: [{ title: "اطلب موقعك — Nova Web Studio" }] }),
  component: OrderPage,
});

function OrderPage() {
  const services = Route.useLoaderData();
  const { service } = Route.useSearch();
  const { L } = useLang();

  return (
    <section className="py-14">
      <div className="container-px mx-auto max-w-3xl">
        <div className="text-center">
          <span className="eyebrow">{L("نظام الطلب", "Project brief")}</span>
          <h1 className="mt-4 text-3xl font-extrabold text-white sm:text-4xl">
            {L("اطلب موقعك الآن", "Start your website")}
          </h1>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            {L(
              "أكمل الخطوات الثلاث وسنراجع طلبك ونعود إليك بعرض واضح.",
              "Complete the three steps and we will review your brief and come back with a clear proposal."
            )}
          </p>
        </div>

        <div className="mt-8">
          <OrderForm services={services} initialService={service || ""} />
        </div>
      </div>
    </section>
  );
}