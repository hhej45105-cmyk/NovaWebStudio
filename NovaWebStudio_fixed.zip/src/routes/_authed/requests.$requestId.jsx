import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft } from "lucide-react";
import RequestWorkspace from "@/components/requests/RequestWorkspace";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/_authed/requests/$requestId")({
  head: () => ({ meta: [{ title: "تفاصيل الطلب — Nova Web Studio" }] }),
  component: ClientRequestPage,
});

function ClientRequestPage() {
  const { requestId } = Route.useParams();
  const { L } = useLang();

  return (
    <section className="py-12">
      <div className="container-px">
        <Link
          to="/dashboard"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground transition hover:text-white"
        >
          <ChevronLeft className="h-3.5 w-3.5 rtl:rotate-180" />
          {L("كل طلباتي", "All my requests")}
        </Link>
        <div className="mt-6">
          <RequestWorkspace requestId={requestId} mode="client" />
        </div>
      </div>
    </section>
  );
}