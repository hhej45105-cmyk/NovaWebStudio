import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Gauge, Layers, ShieldCheck, Sparkles } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/_site/about")({
  head: () => ({
    meta: [
      { title: "من نحن — Nova Web Studio" },
      { name: "description", content: "Nova Web Studio استوديو تصميم وبرمجة مواقع يبدأ رحلته الآن: تصميم فاخر، برمجة نظيفة، وتسليم احترافي." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  const { L, dir } = useLang();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;

  const values = [
    {
      icon: Sparkles,
      ar: "تصميم فاخر",
      en: "Luxury design",
      arDesc: "كل موقع نبنيه يُصمَّم من الصفر لهوية نشاطك، بدون قوالب جاهزة.",
      enDesc: "Every site is designed from scratch around your brand, never a template.",
    },
    {
      icon: Gauge,
      ar: "سرعة وأداء",
      en: "Speed & performance",
      arDesc: "مواقع سريعة على الجوال والكمبيوتر، محسّنة لمحركات البحث.",
      enDesc: "Fast on mobile and desktop, tuned for search engines.",
    },
    {
      icon: ShieldCheck,
      ar: "تسليم واضح",
      en: "Clear delivery",
      arDesc: "مواعيد متفق عليها، مراجعات، ودعم بعد إطلاق الموقع.",
      enDesc: "Agreed timelines, revisions, and support after launch.",
    },
    {
      icon: Layers,
      ar: "كل الأنشطة",
      en: "All business types",
      arDesc: "من متاجر الملابس والمطاعم إلى مجتمعات Discord والمتاجر الإلكترونية.",
      enDesc: "From fashion stores and restaurants to Discord communities and online shops.",
    },
  ];

  return (
    <>
      <section className="relative overflow-hidden border-b border-white/5 py-20">
        <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" />
        <div className="container-px relative">
          <span className="eyebrow">{L("من نحن", "About us")}</span>
          <h1 className="mt-5 max-w-3xl text-3xl font-extrabold leading-tight text-white sm:text-5xl">
            {L("استوديو يبني مواقع تُشبه أصحابها", "A studio that builds websites that feel like you")}
          </h1>
          <p className="mt-5 max-w-2xl text-sm leading-7 text-muted-foreground sm:text-base">
            {L(
              "Nova Web Studio استوديو متخصص في تصميم وبرمجة المواقع الإلكترونية، نطلق خدماته الآن بفلسفة واحدة: أن يحصل كل عميل على موقع يليق بمشروعه من أول مرة. نعمل مع أصحاب المتاجر والمطاعم والبراندات الشخصية ومجتمعات Discord وكل من يريد حضوراً رقمياً حقيقياً.",
              "Nova Web Studio specialises in web design and development and is launching its services now with a single philosophy: every client gets a website worthy of their project from day one. We work with store owners, restaurants, personal brands, Discord communities and anyone who wants a real digital presence."
            )}
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/order" className="neon-btn">
              {L("اطلب موقعك الآن", "Start your project")}
              <Arrow className="h-4 w-4" />
            </Link>
            <Link to="/work" className="ghost-btn">
              {L("شاهد أعمالنا", "View our work")}
            </Link>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container-px grid gap-4 sm:grid-cols-2">
          {values.map((value) => (
            <div key={value.en} className="glass-card p-6">
              <span className="grid h-11 w-11 place-items-center rounded-xl border border-primary/30 bg-primary/10 text-primary">
                <value.icon className="h-5 w-5" />
              </span>
              <h3 className="mt-4 text-lg font-bold text-white">{L(value.ar, value.en)}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {L(value.arDesc, value.enDesc)}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-t border-white/5 py-16">
        <div className="container-px">
          <h2 className="text-2xl font-extrabold text-white">{L("كيف نعمل معك", "How we work")}</h2>
          <div className="mt-8 grid gap-4 md:grid-cols-4">
            {[
              { ar: "1. ترسل الطلب", en: "1. You send the brief" },
              { ar: "2. نراجع ونقترح", en: "2. We review and propose" },
              { ar: "3. نصمم ونبرمج", en: "3. We design and build" },
              { ar: "4. نسلم ونطلع الموقع", en: "4. We deliver and launch" },
            ].map((step) => (
              <div key={step.en} className="rounded-xl border border-white/10 bg-white/[0.03] p-5">
                <p className="text-sm font-bold text-white">{L(step.ar, step.en)}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}