import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Mail, MessageCircle, Phone, Send, CheckCircle2, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getSiteConfig } from "@/lib/server-fns";
import Field from "@/components/order/Field";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/_site/contact")({
  loader: () => getSiteConfig(),
  head: () => ({
    meta: [
      { title: "تواصل معنا — Nova Web Studio" },
      { name: "description", content: "تواصل مع Nova Web Studio عبر النموذج أو WhatsApp وDiscord لبدء مشروع موقعك." },
    ],
  }),
  component: ContactPage,
});

const EMPTY = { name: "", email: "", phone: "", subject: "", message: "" };

function ContactPage() {
  const config = Route.useLoaderData();
  const { L } = useLang();
  const [form, setForm] = useState(EMPTY);
  const [status, setStatus] = useState("idle");
  const set = (key) => (e) => setForm((prev) => ({ ...prev, [key]: e.target.value }));

  const submit = async (event) => {
    event.preventDefault();
    setStatus("sending");
    try {
      await base44.entities.ContactMessage.create(form);
      setForm(EMPTY);
      setStatus("sent");
    } catch (error) {
      setStatus("error");
    }
  };

  const channels = [
    config?.whatsapp_url && {
      href: config.whatsapp_url,
      icon: MessageCircle,
      ar: "WhatsApp",
      en: "WhatsApp",
    },
    config?.discord_url && { href: config.discord_url, icon: MessageCircle, ar: "Discord", en: "Discord" },
    config?.contact_email && {
      href: `mailto:${config.contact_email}`,
      icon: Mail,
      ar: config.contact_email,
      en: config.contact_email,
    },
    config?.contact_phone && {
      href: `tel:${config.contact_phone}`,
      icon: Phone,
      ar: config.contact_phone,
      en: config.contact_phone,
    },
  ].filter(Boolean);

  return (
    <>
      <section className="relative overflow-hidden border-b border-white/5 py-16">
        <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" />
        <div className="container-px relative text-center">
          <span className="eyebrow">{L("تواصل معنا", "Contact us")}</span>
          <h1 className="mx-auto mt-5 max-w-2xl text-3xl font-extrabold leading-tight text-white sm:text-5xl">
            {L("لنتحدث عن موقعك", "Let's talk about your website")}
          </h1>
        </div>
      </section>

      <section className="py-16">
        <div className="container-px grid gap-8 lg:grid-cols-[1.4fr_1fr]">
          <div className="glass-card p-6 sm:p-8">
            <form onSubmit={submit} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label={L("الاسم", "Name")} required>
                  <input className="field" value={form.name} onChange={set("name")} required />
                </Field>
                <Field label={L("البريد الإلكتروني", "Email")}>
                  <input
                    type="email"
                    className="field"
                    value={form.email}
                    onChange={set("email")}
                  />
                </Field>
                <Field label={L("رقم الجوال / تواصل", "Phone / contact")}>
                  <input className="field" value={form.phone} onChange={set("phone")} />
                </Field>
                <Field label={L("الموضوع", "Subject")}>
                  <input className="field" value={form.subject} onChange={set("subject")} />
                </Field>
              </div>
              <Field label={L("رسالتك", "Your message")} required>
                <textarea
                  className="field min-h-32"
                  value={form.message}
                  onChange={set("message")}
                  required
                />
              </Field>

              <button type="submit" disabled={status === "sending"} className="neon-btn w-full">
                <Send className="h-4 w-4" />
                {status === "sending" ? L("جارٍ الإرسال...", "Sending...") : L("إرسال الرسالة", "Send message")}
              </button>

              {status === "sent" && (
                <p className="flex items-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300">
                  <CheckCircle2 className="h-4 w-4" />
                  {L("تم إرسال رسالتك بنجاح، سنرد عليك قريباً.", "Your message was sent. We will reply soon.")}
                </p>
              )}
              {status === "error" && (
                <p className="flex items-center gap-2 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">
                  <AlertCircle className="h-4 w-4" />
                  {L("تعذّر الإرسال، حاول مرة أخرى.", "Could not send. Please try again.")}
                </p>
              )}
            </form>
          </div>

          <div className="space-y-4">
            <div className="glass-card p-6">
              <h2 className="text-sm font-bold text-white">{L("قنوات التواصل", "Contact channels")}</h2>
              {channels.length === 0 ? (
                <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
                  {L(
                    "أرسل رسالتك من النموذج وسنعاود التواصل معك. يمكن إضافة روابط WhatsApp وDiscord من لوحة التحكم.",
                    "Send us a message here and we will get back to you. WhatsApp and Discord links can be added from the dashboard."
                  )}
                </p>
              ) : (
                <ul className="mt-4 space-y-2">
                  {channels.map((channel) => (
                    <li key={channel.href}>
                      <a
                        href={channel.href}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-3 rounded-xl border border-white/10 px-3.5 py-3 text-sm text-white/85 transition hover:border-primary/40 hover:text-white"
                      >
                        <channel.icon className="h-4 w-4 text-primary" />
                        {L(channel.ar, channel.en)}
                      </a>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="glass-card p-6">
              <h2 className="text-sm font-bold text-white">{L("جاهز للطلب؟", "Ready to order?")}</h2>
              <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                {L(
                  "استخدم نموذج الطلب المفصل لتحصل على عرض أدق وأسرع.",
                  "Use the detailed order form for a faster, more accurate proposal."
                )}
              </p>
              <a href="/order" className="neon-btn mt-4 w-full">
                {L("اطلب موقعك", "Request a website")}
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}