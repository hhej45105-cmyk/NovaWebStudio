import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/_site/faq")({
  head: () => ({
    meta: [
      { title: "الأسئلة الشائعة — Nova Web Studio" },
      { name: "description", content: "أجوبة عن مدة التنفيذ، الأسعار، التعديلات، الدفع، والملكية الكاملة للموقع." },
    ],
  }),
  component: FaqPage,
});

const FAQS = [
  {
    ar: "كم تستغرق مدة تنفيذ الموقع؟",
    en: "How long does a website take?",
    arA: "تختلف المدة حسب حجم المشروع: المواقع البسيطة تستغرق أياماً، والمتاجر والمشاريع الكبيرة تحتاج وقتاً أطول. نحدد الموعد عند مراجعة الطلب.",
    enA: "It depends on scope: simple sites take days, larger stores and platforms take longer. We confirm the timeline when reviewing your request.",
  },
  {
    ar: "هل السعر ثابت أم يختلف؟",
    en: "Is pricing fixed?",
    arA: "نحدد السعر بعد معرفة تفاصيل مشروعك ومميزاته المطلوبة، ثم يبقى الاتفاق ثابتاً دون مفاجآت.",
    enA: "We set the price after understanding your scope and requested features, then the agreed price stays fixed.",
  },
  {
    ar: "هل أستطيع طلب تعديلات بعد التسليم؟",
    en: "Can I request changes after delivery?",
    arA: "نعم، تشمل كل مشاريعنا مراجعات محددة، ويمكن طلب تعديلات إضافية بعد التسليم.",
    enA: "Yes — every project includes revision rounds, and additional changes can be requested after delivery.",
  },
  {
    ar: "هل الموقع سيكون متوافقاً مع الجوال؟",
    en: "Will the website work on mobile?",
    arA: "كل مواقعنا مصممة أولاً للجوال ثم للكمبيوتر، وتُختبر على كل المقاسات قبل التسليم.",
    enA: "Every site is designed mobile-first and tested on all screen sizes before delivery.",
  },
  {
    ar: "من يملك الموقع والملفات بعد الانتهاء؟",
    en: "Who owns the website after completion?",
    arA: "أنت تملك تصميم موقعك وبياناته بالكامل، ونضع كل الملفات تحت تصرفك.",
    enA: "You own your design and content fully, and we hand over all the files.",
  },
  {
    ar: "هل يمكنني متابعة حالة طلبي؟",
    en: "Can I track my request?",
    arA: "نعم، بعد إنشاء حساب وإرسال الطلب يمكنك متابعة الحالة والتواصل معنا عبر لوحة حسابك.",
    enA: "Yes — once you create an account and send a request you can follow its status and chat with us from your dashboard.",
  },
  {
    ar: "هل تدعمون متاجر ومجتمعات Discord؟",
    en: "Do you support Discord stores and communities?",
    arA: "نعم، لدينا خدمات مخصصة لمتاجر Discord، شحن الخدمات، ومواقع السيرفرات.",
    enA: "Yes — we have dedicated services for Discord stores, top-ups and server websites.",
  },
  {
    ar: "كيف يتم التواصل أثناء المشروع؟",
    en: "How do we communicate during the project?",
    arA: "عبر محادثة داخل حسابك في الموقع، إضافة إلى WhatsApp أو Discord إن رغبت.",
    enA: "Through the chat in your account, plus WhatsApp or Discord if you prefer.",
  },
];

function FaqPage() {
  const { L } = useLang();

  return (
    <>
      <section className="relative overflow-hidden border-b border-white/5 py-20">
        <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" />
        <div className="container-px relative text-center">
          <span className="eyebrow">{L("الأسئلة الشائعة", "FAQ")}</span>
          <h1 className="mx-auto mt-5 max-w-3xl text-3xl font-extrabold leading-tight text-white sm:text-5xl">
            {L("كل ما تريد معرفته قبل الطلب", "Everything you want to know before ordering")}
          </h1>
        </div>
      </section>

      <section className="py-16">
        <div className="container-px mx-auto max-w-3xl">
          <Accordion type="single" collapsible className="space-y-3">
            {FAQS.map((faq, index) => (
              <AccordionItem
                key={faq.en}
                value={`faq-${index}`}
                className="glass-card overflow-hidden px-5"
              >
                <AccordionTrigger className="py-4 text-start text-sm font-bold text-white hover:no-underline">
                  {L(faq.ar, faq.en)}
                </AccordionTrigger>
                <AccordionContent className="pb-4 text-sm leading-7 text-muted-foreground">
                  {L(faq.arA, faq.enA)}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="mt-12 text-center">
            <p className="text-sm text-muted-foreground">
              {L("لم تجد إجابتك؟", "Didn't find your answer?")}
            </p>
            <Link to="/contact" className="neon-btn mt-4">
              {L("تواصل معنا", "Contact us")}
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}