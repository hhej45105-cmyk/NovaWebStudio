import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, ClipboardCheck, PenTool, Rocket, Code2 } from "lucide-react";
import IntroScreen from "@/components/home/IntroScreen";
import HeroSection from "@/components/home/HeroSection";
import ServiceCard from "@/components/services/ServiceCard";
import ProjectCard from "@/components/work/ProjectCard";
import SectionHeading from "@/components/site/SectionHeading";
import ReviewsSection from "@/components/reviews/ReviewsSection";
import { listProjects, listReviews, listServices } from "@/lib/server-fns";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/_site/")({
  loader: async () => {
    const [services, projects, reviews] = await Promise.all([
      listServices(),
      listProjects(),
      listReviews(),
    ]);
    return { services, projects, reviews };
  },
  head: () => ({
    meta: [
      { title: "Nova Web Studio — أنت تحلم بموقعك، ونحن نصنعه لك" },
      {
        name: "description",
        content:
          "Nova Web Studio وكالة تصميم وبرمجة مواقع: متاجر، مطاعم، Discord، ألعاب، شركات وبراندات شخصية. اطلب موقعك الآن.",
      },
    ],
  }),
  component: HomePage,
});

const STEPS = [
  {
    icon: ClipboardCheck,
    ar: "أرسل طلبك",
    en: "Send your brief",
    arDesc: "املأ نموذج الطلب بتفاصيل نشاطك وأفكارك وملفاتك.",
    enDesc: "Fill the order form with your business details, ideas and files.",
  },
  {
    icon: PenTool,
    ar: "التصميم",
    en: "Design",
    arDesc: "نصمم واجهة مخصصة لهوية مشروعك ونعتمدها معك.",
    enDesc: "We design a custom interface for your brand and get your approval.",
  },
  {
    icon: Code2,
    ar: "البرمجة",
    en: "Development",
    arDesc: "نبني الموقع بسرعة عالية وربط كامل بكل الوظائف.",
    enDesc: "We build it fast with every feature fully wired.",
  },
  {
    icon: Rocket,
    ar: "التسليم",
    en: "Launch",
    arDesc: "نسلم الموقع جاهزاً ونبقى معك للدعم بعد الإطلاق.",
    enDesc: "We hand over the finished site and stay for post-launch support.",
  },
];

function HomePage() {
  const { services, projects, reviews } = Route.useLoaderData();
  const { L, dir } = useLang();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;

  return (
    <>
      <IntroScreen />
      <HeroSection />

      <section id="services" className="relative border-t border-white/5 py-24">
        <div className="container-px">
          <SectionHeading
            eyebrow={L("خدماتنا", "Our services")}
            title={L("12 نوع موقع جاهز لتنفيذ فكرتك", "12 website types ready for your idea")}
            description={L(
              "اختر نوع نشاطك التجاري، ونحن نبني لك موقعاً مخصصاً بالكامل بتصميم وتجربة استخدام تناسب جمهورك.",
              "Pick your business type and we build a fully custom website with a design and experience made for your audience."
            )}
          />
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {services.slice(0, 6).map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
          <div className="mt-8 text-center">
            <Link to="/services" className="ghost-btn">
              {L("كل الخدمات", "All services")}
              <Arrow className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <section className="relative border-t border-white/5 py-20">
        <div className="container-px">
          <SectionHeading
            eyebrow={L("كيف نعمل", "How we work")}
            title={L("أربع خطوات من الفكرة إلى موقع يعمل", "Four steps from idea to a live website")}
            description={L(
              "عملية واضحة وشفافة، تعرف فيها في أي مرحلة مشروعك وماذا ننتظر منك.",
              "A clear, transparent process — you always know where your project stands."
            )}
          />
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((step, index) => (
              <div key={step.en} className="glass-card relative p-6">
                <span className="absolute end-4 top-4 font-display text-4xl font-bold text-white/5">
                  0{index + 1}
                </span>
                <span className="grid h-11 w-11 place-items-center rounded-xl border border-primary/30 bg-primary/10 text-primary">
                  <step.icon className="h-5 w-5" />
                </span>
                <h3 className="mt-4 text-base font-bold text-white">{L(step.ar, step.en)}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {L(step.arDesc, step.enDesc)}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {projects.length > 0 && (
        <section className="border-t border-white/5 py-20">
          <div className="container-px">
            <SectionHeading
              eyebrow={L("أعمالنا", "Selected work")}
              title={L("نماذج من تصاميمنا", "A look at our designs")}
              description={L(
                "كل مشروع بدأ بفكرة عميل، وانتهى بموقع كامل الهوية.",
                "Every project started with a client idea and ended as a complete brand experience."
              )}
            />
            <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {projects.slice(0, 3).map((project) => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
            <div className="mt-8 text-center">
              <Link to="/work" className="ghost-btn">
                {L("شاهد كل الأعمال", "View all work")}
                <Arrow className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </section>
      )}

      <ReviewsSection reviews={reviews} />

      <section className="relative overflow-hidden py-20">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(70%_100%_at_50%_100%,hsl(197_100%_50%_/_0.18),transparent)]" />
        <div className="container-px relative">
          <div className="glass-card flex flex-col items-center gap-6 p-10 text-center md:flex-row md:justify-between md:text-start">
            <div>
              <h3 className="text-2xl font-extrabold text-white sm:text-3xl">
                {L("جاهز تبدأ موقعك؟", "Ready to start your website?")}
              </h3>
              <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">
                {L(
                  "أرسل تفاصيل مشروعك في دقائق، وسنتواصل معك لتحويل الفكرة إلى موقع احترافي.",
                  "Send your project details in minutes and we will turn the idea into a professional website."
                )}
              </p>
            </div>
            <Link to="/order" className="neon-btn shrink-0">
              {L("اطلب موقعك الآن", "Request your website")}
              <Arrow className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}