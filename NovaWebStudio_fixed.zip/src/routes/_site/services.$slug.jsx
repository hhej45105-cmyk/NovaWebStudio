import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Check, ChevronLeft } from "lucide-react";
import { Image } from "@/components/ui/image";
import { getService } from "@/lib/server-fns";
import ProjectCard from "@/components/work/ProjectCard";
import ServiceIcon from "@/components/services/serviceIcon";
import { useLang } from "@/lib/LanguageContext";
import { serviceImage } from "@/lib/media";

export const Route = createFileRoute("/_site/services/$slug")({
  loader: async ({ params }) => {
    const data = await getService({ data: { slug: params.slug } });
    if (!data) throw notFound();
    return data;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.service?.title_ar || "خدمة"} — Nova Web Studio` },
      { name: "description", content: loaderData?.service?.short_ar || "خدمة تصميم وبرمجة مواقع من Nova Web Studio" },
    ],
  }),
  component: ServiceDetailPage,
});

function ServiceDetailPage() {
  const { service, related } = Route.useLoaderData();
  const { L, dir } = useLang();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;
  const features = (L(service.features_ar, service.features_en) || []).filter(Boolean);

  return (
    <>
      <section className="relative border-b border-white/5">
        <div className="container-px py-8">
          <Link
            to="/services"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground transition hover:text-white"
          >
            <ChevronLeft className="h-3.5 w-3.5 rtl:rotate-180" />
            {L("كل الخدمات", "All services")}
          </Link>

          <div className="mt-6 grid gap-10 lg:grid-cols-[1.15fr_1fr] lg:items-center">
            <div>
              <span className="grid h-14 w-14 place-items-center rounded-2xl border border-primary/30 bg-primary/10 text-primary">
                <ServiceIcon name={service.icon} className="h-7 w-7" />
              </span>
              <h1 className="mt-5 text-3xl font-extrabold leading-tight text-white sm:text-4xl">
                {L(service.title_ar, service.title_en)}
              </h1>
              <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">
                {L(service.short_ar, service.short_en)}
              </p>
              <div className="mt-7 flex flex-wrap gap-3">
                <Link to="/order" search={{ service: service.slug }} className="neon-btn">
                  {L("اطلب تصميم هذا الموقع", "Request this website")}
                  <Arrow className="h-4 w-4" />
                </Link>
                <Link to="/work" className="ghost-btn">
                  {L("شاهد أعمالاً مشابهة", "See similar work")}
                </Link>
              </div>
            </div>

            <div className="relative h-64 overflow-hidden rounded-2xl border border-primary/20 bg-[radial-gradient(120%_120%_at_30%_0%,hsl(197_100%_50%_/_0.3),hsl(220_60%_4%_/_0.92))] sm:h-80">
              <Image
                src={serviceImage(service)}
                alt={L(service.title_ar, service.title_en)}
                fittingType="fill"
                className="absolute inset-0 h-full w-full object-cover"
              />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#04070d]/80 to-transparent" />
            </div>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container-px grid gap-10 lg:grid-cols-[1.6fr_1fr]">
          <div className="space-y-10">
            <div>
              <h2 className="text-xl font-extrabold text-white">{L("شرح الخدمة", "About this service")}</h2>
              <p className="mt-3 whitespace-pre-line text-sm leading-7 text-muted-foreground">
                {L(service.description_ar, service.description_en) ||
                  L(service.short_ar, service.short_en)}
              </p>
            </div>

            {features.length > 0 && (
              <div>
                <h2 className="text-xl font-extrabold text-white">
                  {L("مميزات الموقع الذي سيتم إنشاؤه", "What your website will include")}
                </h2>
                <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                  {features.map((feature) => (
                    <li
                      key={feature}
                      className="flex items-start gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3.5 text-sm text-white/85"
                    >
                      <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-primary/20 text-primary">
                        <Check className="h-3 w-3" />
                      </span>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <aside className="lg:sticky lg:top-24 lg:self-start">
            <div className="glass-card p-6">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary">
                {L("السعر", "Pricing")}
              </p>
              <p className="mt-2 text-2xl font-extrabold text-white">
                {typeof service.price_from === "number" && service.price_from > 0
                  ? L(`يبدأ من ${service.price_from}$`, `From $${service.price_from}`)
                  : L("حسب متطلبات المشروع", "Based on project scope")}
              </p>
              <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                {L(
                  "نحدد السعر النهائي بعد مراجعة طلبك ومتطلباتك التفصيلية.",
                  "The final price is set after reviewing your request and requirements."
                )}
              </p>
              <Link to="/order" search={{ service: service.slug }} className="neon-btn mt-5 w-full">
                {L("اطلب هذا الموقع", "Order this website")}
              </Link>
              <Link to="/contact" className="ghost-btn mt-2 w-full">
                {L("تحدث معنا أولاً", "Talk to us first")}
              </Link>
            </div>
          </aside>
        </div>
      </section>

      {related.length > 0 && (
        <section className="border-t border-white/5 py-16">
          <div className="container-px">
            <h2 className="text-xl font-extrabold text-white">
              {L("نماذج من أعمال مشابهة", "Similar work")}
            </h2>
            <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((project) => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );
}