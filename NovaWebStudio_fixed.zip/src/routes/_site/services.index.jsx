import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { listServices } from "@/lib/server-fns";
import ServiceCard from "@/components/services/ServiceCard";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/_site/services/")({
  loader: () => listServices(),
  head: () => ({
    meta: [
      { title: "خدماتنا — Nova Web Studio" },
      { name: "description", content: "12 نوع موقع إلكتروني نبنيه لك: متاجر، مطاعم، Discord، ألعاب، شركات، براندات شخصية والمزيد." },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  const services = Route.useLoaderData();
  const { L, dir } = useLang();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;

  return (
    <>
      <section className="relative overflow-hidden border-b border-white/5 py-20">
        <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" />
        <div className="pointer-events-none absolute inset-x-0 top-0 h-full bg-[radial-gradient(60%_70%_at_50%_0%,hsl(197_100%_50%_/_0.2),transparent)]" />
        <div className="container-px relative text-center">
          <span className="eyebrow">{L("خدماتنا", "Services")}</span>
          <h1 className="mx-auto mt-5 max-w-3xl text-3xl font-extrabold leading-tight text-white sm:text-5xl">
            {L("اختر نوع موقعك، ونحن نبني الباقي", "Pick your website type, we build the rest")}
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
            {L(
              "كل خدمة تُسلَّم بتصميم مخصص بالكامل، سرعة عالية، توافق مع الجوال، وتحسين لمحركات البحث.",
              "Every service ships with a fully custom design, high speed, mobile responsiveness and SEO built in."
            )}
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="container-px">
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>

          <div className="glass-card mt-14 flex flex-col items-center justify-between gap-5 p-8 text-center md:flex-row md:text-start">
            <p className="text-lg font-bold text-white">
              {L("نشاطك غير موجود في القائمة؟", "Your business not on the list?")}
            </p>
            <Link to="/order" className="neon-btn">
              {L("اطلب موقعك المخصص", "Request a custom website")}
              <Arrow className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}