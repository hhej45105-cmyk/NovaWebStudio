import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, ChevronLeft, ExternalLink } from "lucide-react";
import { Image } from "@/components/ui/image";
import { getProject } from "@/lib/server-fns";
import { useLang } from "@/lib/LanguageContext";
import { projectImage } from "@/lib/media";

export const Route = createFileRoute("/_site/work/$projectId")({
  loader: async ({ params }) => {
    const project = await getProject({ data: { id: params.projectId } });
    if (!project) throw notFound();
    return project;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.title_ar || "مشروع"} — Nova Web Studio` },
      { name: "description", content: loaderData?.description_ar || "مشروع من أعمال Nova Web Studio" },
    ],
  }),
  component: ProjectDetailPage,
});

function ProjectDetailPage() {
  const project = Route.useLoaderData();
  const { L, dir } = useLang();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;
  const gallery = (project.gallery || []).filter(Boolean);

  return (
    <>
      <section className="border-b border-white/5">
        <div className="container-px py-8">
          <Link
            to="/work"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground transition hover:text-white"
          >
            <ChevronLeft className="h-3.5 w-3.5 rtl:rotate-180" />
            {L("كل الأعمال", "All work")}
          </Link>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <span className="eyebrow">{L(project.category_ar, project.category_en)}</span>
            {project.live_url && (
              <a
                href={project.live_url}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-primary hover:underline"
              >
                <ExternalLink className="h-3.5 w-3.5" />
                {L("زيارة الموقع", "Visit website")}
              </a>
            )}
          </div>

          <h1 className="mt-4 text-3xl font-extrabold text-white sm:text-5xl">
            {L(project.title_ar, project.title_en)}
          </h1>
          <p className="mt-4 max-w-3xl text-sm leading-7 text-muted-foreground sm:text-base">
            {L(project.description_ar, project.description_en)}
          </p>
        </div>
      </section>

      <section className="py-10">
        <div className="container-px">
          <div className="relative h-72 overflow-hidden rounded-2xl border border-primary/20 bg-[radial-gradient(120%_120%_at_70%_0%,hsl(197_100%_50%_/_0.3),hsl(220_60%_4%_/_0.92))] sm:h-[28rem]">
            <Image
              src={projectImage(project)}
              alt={L(project.title_ar, project.title_en)}
              fittingType="fill"
              className="absolute inset-0 h-full w-full object-cover"
            />
          </div>

          {gallery.length > 0 && (
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              {gallery.map((image, index) => (
                <div key={image} className="overflow-hidden rounded-xl border border-white/10">
                  <Image
                    src={image}
                    alt={`${L(project.title_ar, project.title_en)} ${index + 1}`}
                    fittingType="fill"
                    className="h-56 w-full object-cover"
                  />
                </div>
              ))}
            </div>
          )}

          <div className="mt-10 grid gap-8 lg:grid-cols-[1.5fr_1fr]">
            <div>
              <h2 className="text-lg font-extrabold text-white">
                {L("تفاصيل المشروع", "Project details")}
              </h2>
              <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
                <li className="flex justify-between gap-4 border-b border-white/5 pb-3">
                  <span>{L("نوع الموقع", "Website type")}</span>
                  <span className="font-semibold text-white">
                    {L(project.category_ar, project.category_en)}
                  </span>
                </li>
                <li className="flex justify-between gap-4 border-b border-white/5 pb-3">
                  <span>{L("التقنيات", "Stack")}</span>
                  <span className="font-semibold text-white">
                    {(project.tags_en || []).join(" · ") || "—"}
                  </span>
                </li>
                <li className="flex justify-between gap-4">
                  <span>{L("الحالة", "Status")}</span>
                  <span className="font-semibold text-white">{L("منشور", "Published")}</span>
                </li>
              </ul>
            </div>

            <div className="glass-card p-6">
              <p className="text-sm font-bold text-white">
                {L("تريد موقعاً بهذا المستوى؟", "Want a website at this level?")}
              </p>
              <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                {L(
                  "أرسل تفاصيل مشروعك وسنقوم بتصميمه وبرمجته خصيصاً لك.",
                  "Send your project details and we will design and build it just for you."
                )}
              </p>
              <Link to="/order" className="neon-btn mt-5 w-full">
                {L("اطلب موقعك الآن", "Start your project")}
                <Arrow className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}