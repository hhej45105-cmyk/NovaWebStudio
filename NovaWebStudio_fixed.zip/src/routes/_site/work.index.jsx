import { createFileRoute, Link } from "@tanstack/react-router";
import { listProjects } from "@/lib/server-fns";
import ProjectCard from "@/components/work/ProjectCard";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/_site/work/")({
  loader: () => listProjects(),
  head: () => ({
    meta: [
      { title: "أعمالنا — Nova Web Studio" },
      { name: "description", content: "نماذج مواقع من تصميم وبرمجة Nova Web Studio: متاجر، مطاعم، كافيهات، Discord، ألعاب ومتاجر إلكترونية." },
    ],
  }),
  component: WorkPage,
});

function WorkPage() {
  const projects = Route.useLoaderData();
  const { L } = useLang();

  return (
    <>
      <section className="relative overflow-hidden border-b border-white/5 py-20">
        <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" />
        <div className="pointer-events-none absolute inset-x-0 top-0 h-full bg-[radial-gradient(60%_70%_at_50%_0%,hsl(197_100%_50%_/_0.18),transparent)]" />
        <div className="container-px relative text-center">
          <span className="eyebrow">{L("معرض الأعمال", "Portfolio")}</span>
          <h1 className="mx-auto mt-5 max-w-3xl text-3xl font-extrabold leading-tight text-white sm:text-5xl">
            {L("مواقع بنيناها بدقة البكسل", "Websites built pixel by pixel")}
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
            {L(
              "نماذج تعرض أسلوبنا في التصميم والتجربة: هوية بصرية قوية، سرعة، وواجهات تُقنع الزائر.",
              "Concept work that shows our design language: strong identity, speed and interfaces that convert."
            )}
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="container-px">
          {projects.length === 0 ? (
            <div className="glass-card p-10 text-center text-sm text-muted-foreground">
              {L("لا توجد مشاريع منشورة حالياً.", "No published projects yet.")}
            </div>
          ) : (
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {projects.map((project) => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          )}

          <div className="mt-14 text-center">
            <Link to="/order" className="neon-btn">
              {L("أريد موقعاً مثل هذه الأعمال", "I want a website like these")}
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}