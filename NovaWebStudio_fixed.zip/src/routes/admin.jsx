import { Outlet, createFileRoute, redirect } from "@tanstack/react-router";
import { AuthGateError, requireSignedIn } from "@/components/auth/AuthGate";
import AdminShell from "@/components/admin/AdminShell";

export const Route = createFileRoute("/admin")({
  ssr: false,
  beforeLoad: async (ctx) => {
    const { user } = await requireSignedIn(ctx);
    if (user?.role !== "admin") throw redirect({ to: "/dashboard" });
    return { user };
  },
  errorComponent: AuthGateError,
  component: AdminLayout,
});

function AdminLayout() {
  return (
    <AdminShell>
      <Outlet />
    </AdminShell>
  );
}