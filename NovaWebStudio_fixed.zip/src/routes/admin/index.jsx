import { useEffect, useState } from "react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Search } from "lucide-react";
import { base44 } from "@/api/base44Client";
import StatusBadge, { STATUS_LABELS } from "@/components/admin/StatusBadge";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/admin/")({
  head: () => ({ meta: [{ title: "طلبات العملاء — Nova Web Studio" }] }),
  component: AdminRequestsPage,
});

const FILTERS = ["all", "new", "review", "in_progress", "completed", "rejected"];

function AdminRequestsPage() {
  const { L, dir } = useLang();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");

  useEffect(() => {
    base44.entities.ServiceRequest.filter({}, { sort: "-created_date", limit: 200 })
      .then((page) => setRequests(page.items || []))
      .finally(() => setLoading(false));
  }, []);

  const counts = requests.reduce((acc, request) => {
    acc[request.status] = (acc[request.status] || 0) + 1;
    return acc;
  }, {});

  const visible = requests.filter((request) => {
    const matchesStatus = filter === "all" || request.status === filter;
    const search = query.trim().toLowerCase();
    const matchesQuery =
      !search ||
      [request.order_code, request.client_name, request.brand_name, request.service_title, request.contact_value]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(search));
    return matchesStatus && matchesQuery;
  });

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white">{L("طلبات العملاء", "Client requests")}</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {L(`إجمالي ${requests.length} طلب`, `${requests.length} requests in total`)}
          </p>
        </div>
        <div className="relative">
          <Search className="pointer-events-none absolute end-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            className="field !py-2 pe-9"
            placeholder={L("بحث بالاسم أو الرقم", "Search by name or code")}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
          />
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        {FILTERS.map((value) => {
          const label =
            value === "all"
              ? L("الكل", "All")
              : L(STATUS_LABELS[value].ar, STATUS_LABELS[value].en);
          const count = value === "all" ? requests.length : counts[value] || 0;
          return (
            <button
              key={value}
              type="button"
              onClick={() => setFilter(value)}
              className={`rounded-full border px-3.5 py-1.5 text-xs font-bold transition ${
                filter === value
                  ? "border-primary bg-primary/20 text-white"
                  : "border-white/15 text-muted-foreground hover:text-white"
              }`}
            >
              {label} ({count})
            </button>
          );
        })}
      </div>

      <div className="mt-6 space-y-3">
        {loading && <p className="text-sm text-muted-foreground">{L("جارٍ التحميل...", "Loading...")}</p>}
        {!loading && visible.length === 0 && (
          <div className="glass-card p-10 text-center text-sm text-muted-foreground">
            {L("لا توجد طلبات مطابقة.", "No matching requests.")}
          </div>
        )}

        {visible.map((request) => (
          <Link
            key={request.id}
            to="/admin/requests/$requestId"
            params={{ requestId: request.id }}
            className="glass-card flex flex-wrap items-center justify-between gap-4 p-4"
          >
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-[11px] text-primary">{request.order_code}</span>
                <span className="text-sm font-bold text-white">
                  {request.brand_name || request.client_name}
                </span>
              </div>
              <p className="mt-1 truncate text-xs text-muted-foreground">
                {request.client_name} · {request.service_title || request.service_slug} ·{" "}
                {request.contact_method}: {request.contact_value}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <StatusBadge
                status={request.status}
                label={L(
                  STATUS_LABELS[request.status]?.ar || request.status,
                  STATUS_LABELS[request.status]?.en || request.status
                )}
              />
              <Arrow className="h-4 w-4 text-muted-foreground" />
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}