import { useEffect, useState } from "react";
import { Check, Mail, Phone, Trash2 } from "lucide-react";
import { createFileRoute } from "@tanstack/react-router";
import { base44 } from "@/api/base44Client";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/admin/messages")({
  head: () => ({ meta: [{ title: "رسائل الموقع — Nova Web Studio" }] }),
  component: AdminMessagesPage,
});

function AdminMessagesPage() {
  const { L } = useLang();
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () =>
    base44.entities.ContactMessage.list({ sort: "-created_date", limit: 200 })
      .then((page) => setMessages(page.items || []))
      .finally(() => setLoading(false));

  useEffect(() => {
    load();
  }, []);

  const toggleHandled = async (message) => {
    await base44.entities.ContactMessage.update(message.id, { handled: !message.handled });
    load();
  };

  const remove = async (message) => {
    if (!window.confirm(L("حذف هذه الرسالة؟", "Delete this message?"))) return;
    await base44.entities.ContactMessage.delete(message.id);
    load();
  };

  return (
    <div>
      <h1 className="text-2xl font-extrabold text-white">{L("رسائل الموقع", "Site messages")}</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        {L("رسائل نموذج التواصل.", "Messages from the contact form.")}
      </p>

      <div className="mt-6 space-y-3">
        {loading && <p className="text-sm text-muted-foreground">{L("جارٍ التحميل...", "Loading...")}</p>}
        {!loading && messages.length === 0 && (
          <div className="glass-card p-10 text-center text-sm text-muted-foreground">
            {L("لا توجد رسائل بعد.", "No messages yet.")}
          </div>
        )}

        {messages.map((message) => (
          <div key={message.id} className="glass-card p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="text-sm font-bold text-white">
                  {message.name}
                  {message.subject ? <span className="text-muted-foreground"> — {message.subject}</span> : null}
                </p>
                <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                  {message.email && (
                    <a href={`mailto:${message.email}`} className="inline-flex items-center gap-1 hover:text-white" dir="ltr">
                      <Mail className="h-3 w-3" />
                      {message.email}
                    </a>
                  )}
                  {message.phone && (
                    <a href={`tel:${message.phone}`} className="inline-flex items-center gap-1 hover:text-white" dir="ltr">
                      <Phone className="h-3 w-3" />
                      {message.phone}
                    </a>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => toggleHandled(message)}
                  className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-[11px] font-bold transition ${
                    message.handled
                      ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
                      : "border-white/15 text-muted-foreground hover:text-white"
                  }`}
                >
                  <Check className="h-3 w-3" />
                  {message.handled ? L("تم الرد", "Handled") : L("غير معالجة", "Open")}
                </button>
                <button
                  type="button"
                  onClick={() => remove(message)}
                  className="rounded-lg border border-white/10 p-2 text-muted-foreground transition hover:text-red-400"
                  aria-label={L("حذف", "Delete")}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
            <p className="mt-3 whitespace-pre-line text-sm leading-7 text-muted-foreground">{message.message}</p>
          </div>
        ))}
      </div>
    </div>
  );
}