import { useEffect, useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { createFileRoute } from "@tanstack/react-router";
import { base44 } from "@/api/base44Client";
import ProjectEditor from "@/components/admin/ProjectEditor";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/admin/portfolio")({
  head: () => ({ meta: [{ title: "معرض الأعمال — Nova Web Studio" }] }),
  component: AdminPortfolioPage,
});

function AdminPortfolioPage() {
  const { L } = useLang();
  const [projects, setProjects] = useState([]);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = () =>
    base44.entities.PortfolioProject.list({ sort: "sort_order", limit: 100 })
      .then((page) => setProjects(page.items || []))
      .finally(() => setLoading(false));

  useEffect(() => {
    load();
  }, []);

  const remove = async (project) => {
    if (!window.confirm(L("حذف هذا المشروع؟", "Delete this project?"))) return;
    await base44.entities.PortfolioProject.delete(project.id);
    load();
  };

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white">{L("معرض الأعمال", "Portfolio")}</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {L("أضف مشاريع جديدة لعرضها على الموقع.", "Add new projects to show on the site.")}
          </p>
        </div>
        <button type="button" onClick={() => setEditing({})} className="neon-btn">
          <Plus className="h-4 w-4" />
          {L("مشروع جديد", "New project")}
        </button>
      </div>

      <div className="mt-6 space-y-3">
        {loading && <p className="text-sm text-muted-foreground">{L("جارٍ التحميل...", "Loading...")}</p>}
        {projects.map((project) => (
          <div key={project.id} className="glass-card flex flex-wrap items-center justify-between gap-4 p-4">
            <div>
              <p className="text-sm font-bold text-white">{project.title_ar}</p>
              <p className="mt-1 text-xs text-muted-foreground">{project.category_ar}</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setEditing(project)}
                className="rounded-lg border border-white/10 p-2 text-muted-foreground transition hover:text-white"
                aria-label={L("تعديل", "Edit")}
              >
                <Pencil className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => remove(project)}
                className="rounded-lg border border-white/10 p-2 text-muted-foreground transition hover:text-red-400"
                aria-label={L("حذف", "Delete")}
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <Dialog open={!!editing} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto border-white/10 bg-[#070b12] text-white">
          <DialogHeader>
            <DialogTitle>{editing?.id ? L("تعديل المشروع", "Edit project") : L("مشروع جديد", "New project")}</DialogTitle>
          </DialogHeader>
          {editing && (
            <ProjectEditor
              project={editing}
              onSaved={() => {
                setEditing(null);
                load();
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}