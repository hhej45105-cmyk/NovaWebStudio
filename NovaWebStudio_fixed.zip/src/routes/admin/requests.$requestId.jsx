import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft } from "lucide-react";
import RequestWorkspace from "@/components/requests/RequestWorkspace";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/admin/requests/$requestId")({
  head: () => ({ meta: [{ title: "إدارة الطلب — Nova Web Studio" }] }),
  component: AdminRequestPage,
});

function AdminRequestPage() {
  const { requestId } = Route.useParams();
  const { L } = useLang();

  return (
    <div>
      <Link
        to="/admin"
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground transition hover:text-white"
      >
        <ChevronLeft className="h-3.5 w-3.5 rtl:rotate-180" />
        {L("كل الطلبات", "All requests")}
      </Link>
      <div className="mt-5">
        <RequestWorkspace requestId={requestId} mode="admin" />
      </div>
    </div>
  );
}