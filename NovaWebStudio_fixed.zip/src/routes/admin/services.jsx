import { useEffect, useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { createFileRoute } from "@tanstack/react-router";
import { base44 } from "@/api/base44Client";
import ServiceEditor from "@/components/admin/ServiceEditor";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/admin/services")({
  head: () => ({ meta: [{ title: "إدارة الخدمات — Nova Web Studio" }] }),
  component: AdminServicesPage,
});

function AdminServicesPage() {
  const { L } = useLang();
  const [services, setServices] = useState([]);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = () =>
    base44.entities.Service.list({ sort: "sort_order", limit: 100 })
      .then((page) => setServices(page.items || []))
      .finally(() => setLoading(false));

  useEffect(() => {
    load();
  }, []);

  const remove = async (service) => {
    if (!window.confirm(L("حذف هذه الخدمة؟", "Delete this service?"))) return;
    await base44.entities.Service.delete(service.id);
    load();
  };

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white">{L("الخدمات والأسعار", "Services & pricing")}</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {L("أضف أو عدّل الخدمات المعروضة على الموقع.", "Add or edit the services shown on the site.")}
          </p>
        </div>
        <button type="button" onClick={() => setEditing({})} className="neon-btn">
          <Plus className="h-4 w-4" />
          {L("خدمة جديدة", "New service")}
        </button>
      </div>

      <div className="mt-6 space-y-3">
        {loading && <p className="text-sm text-muted-foreground">{L("جارٍ التحميل...", "Loading...")}</p>}
        {services.map((service) => (
          <div key={service.id} className="glass-card flex flex-wrap items-center justify-between gap-4 p-4">
            <div>
              <p className="text-sm font-bold text-white">{service.title_ar}</p>
              <p className="mt-1 text-xs text-muted-foreground" dir="ltr">
                {service.slug} · {service.is_active ? L("ظاهر", "Visible") : L("مخفي", "Hidden")}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setEditing(service)}
                className="rounded-lg border border-white/10 p-2 text-muted-foreground transition hover:text-white"
                aria-label={L("تعديل", "Edit")}
              >
                <Pencil className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => remove(service)}
                className="rounded-lg border border-white/10 p-2 text-muted-foreground transition hover:text-red-400"
                aria-label={L("حذف", "Delete")}
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <Dialog open={!!editing} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto border-white/10 bg-[#070b12] text-white">
          <DialogHeader>
            <DialogTitle>{editing?.id ? L("تعديل الخدمة", "Edit service") : L("خدمة جديدة", "New service")}</DialogTitle>
          </DialogHeader>
          {editing && (
            <ServiceEditor
              service={editing}
              onSaved={() => {
                setEditing(null);
                load();
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}