import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { base44 } from "@/api/base44Client";
import { useLang } from "@/lib/LanguageContext";

export const Route = createFileRoute("/admin/settings")({
  head: () => ({ meta: [{ title: "الإعدادات — Nova Web Studio" }] }),
  component: AdminSettingsPage,
});

const EMPTY = {
  agency_name: "Nova Web Studio",
  contact_email: "",
  contact_phone: "",
  whatsapp_url: "",
  discord_url: "",
  about_ar: "",
  about_en: "",
};

function AdminSettingsPage() {
  const { L } = useLang();
  const [record, setRecord] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.SiteConfig.list({ limit: 1 })
      .then((page) => {
        const first = (page.items || [])[0] || null;
        setRecord(first);
        setForm({ ...EMPTY, ...(first || {}) });
      })
      .finally(() => setLoading(false));
  }, []);

  const set = (key) => (event) => setForm((prev) => ({ ...prev, [key]: event.target.value }));

  const save = async (event) => {
    event.preventDefault();
    const payload = { ...form };
    delete payload.id;
    delete payload.created_date;
    delete payload.updated_date;
    delete payload.created_by_id;
    const result = record
      ? await base44.entities.SiteConfig.update(record.id, payload)
      : await base44.entities.SiteConfig.create(payload);
    setRecord(result);
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2500);
  };

  const fields = [
    ["agency_name", L("اسم الوكالة", "Agency name")],
    ["contact_email", L("البريد الإلكتروني", "Contact email")],
    ["contact_phone", L("رقم الهاتف", "Contact phone")],
    ["whatsapp_url", L("رابط WhatsApp", "WhatsApp URL")],
    ["discord_url", L("رابط Discord", "Discord URL")],
    ["vodafone_number", L("رقم فودافون كاش", "Vodafone Cash number")],
    ["instapay_handle", L("عنوان إنستا باي", "InstaPay address")],
  ];

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-extrabold text-white">{L("الإعدادات", "Settings")}</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        {L(
          "بيانات التواصل التي تظهر للعملاء في الموقع.",
          "Contact details shown to clients across the site."
        )}
      </p>

      {loading ? (
        <p className="mt-6 text-sm text-muted-foreground">{L("جارٍ التحميل...", "Loading...")}</p>
      ) : (
        <form onSubmit={save} className="glass-card mt-6 space-y-3 p-6">
          {fields.map(([key, label]) => (
            <label key={key} className="block">
              <span className="mb-1 block text-[11px] font-bold text-white/70">{label}</span>
              <input
                className="field"
                dir={key === "agency_name" ? undefined : "ltr"}
                value={form[key] || ""}
                onChange={set(key)}
              />
            </label>
          ))}
          <label className="block">
            <span className="mb-1 block text-[11px] font-bold text-white/70">{L("نبذة (عربي)", "About (AR)")}</span>
            <textarea className="field min-h-20" value={form.about_ar || ""} onChange={set("about_ar")} />
          </label>
          <label className="block">
            <span className="mb-1 block text-[11px] font-bold text-white/70">{L("نبذة (إنجليزي)", "About (EN)")}</span>
            <textarea className="field min-h-20" dir="ltr" value={form.about_en || ""} onChange={set("about_en")} />
          </label>
          <button type="submit" className="neon-btn w-full">
            {L("حفظ الإعدادات", "Save settings")}
          </button>
          {saved && <p className="text-xs font-bold text-emerald-400">{L("تم الحفظ", "Saved")}</p>}
        </form>
      )}
    </div>
  );
}