# Nova Web Studio

1. `npm install`
2. أنشئ مشروعاً في Supabase ثم شغّل `supabase/schema.sql` في SQL Editor.
3. انسخ `.env.example` إلى `.env.local` واملأ `NEXT_PUBLIC_SUPABASE_URL` و`NEXT_PUBLIC_SUPABASE_ANON_KEY` و`ANTHROPIC_API_KEY` (للمساعد الذكي).
4. من Authentication > Sign In / Providers فعّل Anonymous Sign-ins (للدردشة المباشرة). لا تعطّل التسجيل العام، فالأمان يعتمد على سياسات RLS.
5. من Authentication > Users اضغط Add user وأنشئ حسابين بكلمة مرور وفعّل Auto Confirm:
   `ahmedkhaleduu3@gmail.com` و`hhej45105@gmail.com`. هذان البريدان فقط هما الإدارة.
6. `npm run dev` ثم افتح `/admin` لتسجيل الدخول.
7. للنشر على Vercel أضف نفس متغيرات `.env.local` في إعدادات المشروع.
