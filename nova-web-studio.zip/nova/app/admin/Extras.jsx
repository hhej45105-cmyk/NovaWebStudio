'use client';
import { useEffect, useState } from 'react';
import { getSb } from '@/lib/supabase';
import { SERVICES } from '@/lib/services';

export function Inbox() {
  const [msgs, setMsgs] = useState([]);
  const [open, setOpen] = useState(null);
  const [text, setText] = useState('');
  useEffect(() => {
    const sb = getSb();
    const load = () => sb.from('messages').select('*').order('created_at').then(({ data }) => setMsgs(data || []));
    load();
    const ch = sb.channel('inbox').on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, load).subscribe();
    return () => { sb.removeChannel(ch); };
  }, []);
  const threads = [...new Set(msgs.map((m) => m.thread))].reverse();
  async function reply(e) {
    e.preventDefault();
    if (!text.trim() || !open) return;
    await getSb().from('messages').insert({ thread: open, sender: 'admin', body: text.trim() });
    setText('');
  }
  return (
    <div className="glass" style={{ padding: '1rem', display: 'grid', gap: '1rem' }}>
      {threads.length === 0 && <p>لا توجد رسائل بعد.</p>}
      <div className="row">{threads.map((th) => <button key={th} className={open === th ? 'btn' : 'btn ghost'} onClick={() => setOpen(th)}>عميل {th.slice(0, 6)}</button>)}</div>
      {open && (
        <>
          <div className="chat-log">{msgs.filter((m) => m.thread === open).map((m) => <p key={m.id} className={m.sender === 'admin' ? 'bubble me' : 'bubble'}>{m.body}</p>)}</div>
          <form className="row" style={{ flexWrap: 'nowrap' }} onSubmit={reply}>
            <input value={text} onChange={(e) => setText(e.target.value)} style={{ flex: 1 }} />
            <button className="btn">إرسال</button>
          </form>
        </>
      )}
    </div>
  );
}

export function Works() {
  const [rows, setRows] = useState([]);
  const load = () => getSb().from('portfolio').select('*').order('created_at', { ascending: false }).then(({ data }) => setRows(data || []));
  useEffect(() => { load(); }, []);
  async function add(e) {
    e.preventDefault();
    const form = e.currentTarget;
    const v = Object.fromEntries(new FormData(form));
    await getSb().from('portfolio').insert({ title: v.title, category: v.category, url: v.url || null, image_url: v.image_url || null });
    form.reset(); load();
  }
  const del = async (id) => { await getSb().from('portfolio').delete().eq('id', id); load(); };
  return (
    <div style={{ display: 'grid', gap: '1.2rem' }}>
      <form className="glass" onSubmit={add}>
        <label>اسم المشروع<input name="title" required /></label>
        <label>نوع الموقع<select name="category">{SERVICES.map((s) => <option key={s.id} value={s.id}>{s.ar}</option>)}</select></label>
        <label>رابط المشروع<input name="url" type="url" /></label>
        <label>رابط صورة المشروع<input name="image_url" type="url" /></label>
        <button className="btn">إضافة للمعرض</button>
      </form>
      <div className="glass" style={{ padding: '1rem' }}>
        {rows.length === 0 && <p>المعرض فارغ.</p>}
        {rows.map((r) => <div key={r.id} className="row" style={{ justifyContent: 'space-between' }}><span>{r.title}</span><button className="btn ghost" onClick={() => del(r.id)}>حذف</button></div>)}
      </div>
    </div>
  );
}

export function Prices() {
  const [p, setP] = useState(null);
  useEffect(() => {
    getSb().from('service_prices').select('*').then(({ data }) => setP(Object.fromEntries((data || []).map((r) => [r.service, r.price]))));
  }, []);
  async function save(id, v) {
    const sb = getSb();
    if (v.trim()) await sb.from('service_prices').upsert({ service: id, price: v.trim() });
    else await sb.from('service_prices').delete().eq('service', id);
  }
  if (!p) return null;
  return (
    <div className="glass" style={{ padding: '1.2rem', display: 'grid', gap: '.8rem' }}>
      {SERVICES.map((s) => <label key={s.id}>{s.ar}<input defaultValue={p[s.id] || ''} placeholder="مثال: 600 جنيه" onBlur={(e) => save(s.id, e.target.value)} /></label>)}
    </div>
  );
}
