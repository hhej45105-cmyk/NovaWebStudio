'use client';
import { useCallback, useEffect, useState } from 'react';
import { getSb } from '@/lib/supabase';
import { Inbox, Works, Prices } from './Extras';

const STATUS = { new: 'جديد', review: 'قيد المراجعة', in_progress: 'قيد التنفيذ', done: 'مكتمل', rejected: 'مرفوض' };

export default function Admin() {
  const [session, setSession] = useState(undefined);
  const [orders, setOrders] = useState([]);
  const [err, setErr] = useState('');
  const [tab, setTab] = useState('orders');
  const [fresh, setFresh] = useState(0);

  const load = useCallback(async () => {
    const { data, error } = await getSb().from('orders').select('*').order('created_at', { ascending: false });
    if (error) setErr('هذا الحساب ليس من حسابات الإدارة.'); else { setErr(''); setOrders(data); }
  }, []);

  useEffect(() => {
    const sb = getSb();
    sb.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: sub } = sb.auth.onAuthStateChange((_, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);
  useEffect(() => {
    if (!session) return;
    load();
    const sb = getSb();
    const ch = sb.channel('admin-orders').on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'orders' }, () => { setFresh((n) => n + 1); load(); }).subscribe();
    return () => { sb.removeChannel(ch); };
  }, [session, load]);

  async function login(e) {
    e.preventDefault();
    const v = Object.fromEntries(new FormData(e.currentTarget));
    const { error } = await getSb().auth.signInWithPassword({ email: v.email, password: v.password });
    if (error) setErr('بيانات الدخول غير صحيحة.');
  }
  const update = async (id, patch) => { await getSb().from('orders').update(patch).eq('id', id); load(); };
  async function openFile(path) {
    const { data } = await getSb().storage.from('order-files').createSignedUrl(path, 300);
    if (data) window.open(data.signedUrl, '_blank');
  }

  if (session === undefined) return null;
  if (!session) return (
    <div className="page"><form className="glass" onSubmit={login} style={{ maxWidth: 420, padding: '1.6rem', display: 'grid', gap: '1rem' }}>
      <h2>لوحة الإدارة</h2>
      <label>البريد<input name="email" type="email" required /></label>
      <label>كلمة المرور<input name="password" type="password" required /></label>
      <button className="btn">دخول</button>{err && <p className="msg bad" role="alert">{err}</p>}
    </form></div>
  );

  return (
    <div className="page">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2>لوحة الإدارة</h2>
        <button className="btn ghost" onClick={() => getSb().auth.signOut()}>خروج</button>
      </div>
      <div className="row" style={{ marginBottom: 16 }}>
        {[['orders', `الطلبات (${orders.length})${fresh ? ' 🔔' + fresh : ''}`], ['chat', 'الرسائل'], ['works', 'المعرض'], ['prices', 'الأسعار']].map(([k, l]) => (
          <button key={k} className={tab === k ? 'btn' : 'btn ghost'} onClick={() => { setTab(k); if (k === 'orders') setFresh(0); }}>{l}</button>
        ))}
      </div>
      {err && <p className="msg bad" role="alert">{err}</p>}
      {tab === 'orders' ? <div className="glass" style={{ overflowX: 'auto' }}>
        <table>
          <thead><tr><th>العميل</th><th>المشروع</th><th>الحالة</th><th>رابط التسليم</th><th>الملفات</th></tr></thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id}>
                <td>{o.name}<br />{o.contact}</td>
                <td><b>{o.brand}</b> ({o.service})<br />{o.description}<br />{o.colors} {o.budget} {o.deadline}</td>
                <td>
                  <select value={o.status} onChange={(e) => update(o.id, { status: e.target.value })}>
                    {Object.entries(STATUS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
                  </select>
                  <div className="row" style={{ marginTop: 6 }}>
                    <button className="btn ghost" onClick={() => update(o.id, { status: 'in_progress' })}>قبول</button>
                    <button className="btn ghost" onClick={() => update(o.id, { status: 'rejected' })}>رفض</button>
                  </div>
                </td>
                <td><input defaultValue={o.delivered_url || ''} placeholder="https://" onBlur={(e) => e.target.value !== (o.delivered_url || '') && update(o.id, { delivered_url: e.target.value || null })} /></td>
                <td>{o.files.map((p, i) => <button key={p} className="btn ghost" onClick={() => openFile(p)}>ملف {i + 1}</button>)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div> : tab === 'chat' ? <Inbox /> : tab === 'works' ? <Works /> : <Prices />}
    </div>
  );
}
