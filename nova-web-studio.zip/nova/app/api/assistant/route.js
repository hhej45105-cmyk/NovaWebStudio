import { SERVICES } from '@/lib/services';

const hits = new Map();
const SYSTEM = `You are the assistant of Nova Web Studio, an agency that designs and programs custom websites for clients.
Services: ${SERVICES.map((s) => s.en).join('; ')}.
Help visitors choose a service, clarify their idea (audience, colors, features, references) and understand how to order: the "Order your website" form, or the live chat with the team.
Never invent prices, delivery times or past projects; say the team confirms them after reviewing the order.
Reply in the visitor's language, briefly (under 120 words), in plain text.`;

export async function POST(req) {
  const ip = req.headers.get('x-forwarded-for') || 'x';
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < 60000);
  if (recent.length >= 15) return Response.json({ error: 'rate' }, { status: 429 });
  hits.set(ip, [...recent, now]);

  const key = process.env.ANTHROPIC_API_KEY;
  const { messages } = await req.json().catch(() => ({}));
  if (!key || !Array.isArray(messages)) return Response.json({ error: 'unavailable' }, { status: 503 });
  const history = messages.slice(-12).map((m) => ({
    role: m.role === 'assistant' ? 'assistant' : 'user',
    content: String(m.content || '').slice(0, 1500),
  }));
  while (history[0] && history[0].role !== 'user') history.shift();
  if (!history.length) return Response.json({ error: 'empty' }, { status: 400 });

  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5', max_tokens: 500, system: SYSTEM, messages: history }),
  });
  if (!r.ok) return Response.json({ error: 'failed' }, { status: 502 });
  const d = await r.json();
  return Response.json({ reply: (d.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('') });
}
