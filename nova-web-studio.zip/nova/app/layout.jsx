import { Cairo, Space_Grotesk } from 'next/font/google';
import Shell from '@/components/Shell';
import './globals.css';

const cairo = Cairo({ subsets: ['arabic', 'latin'], variable: '--f-body', display: 'swap' });
const grotesk = Space_Grotesk({ subsets: ['latin'], variable: '--f-brand', display: 'swap' });

export const metadata = {
  title: 'Nova Web Studio',
  description: 'وكالة تصميم وبرمجة المواقع الإلكترونية حسب طلب العميل.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl" className={`${cairo.variable} ${grotesk.variable}`}>
      <body><Shell>{children}</Shell></body>
    </html>
  );
}
