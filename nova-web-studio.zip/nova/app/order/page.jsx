'use client';
import { useEffect, useState } from 'react';
import { useLang } from '@/lib/i18n';
import { SERVICES } from '@/lib/services';
import { getSb } from '@/lib/supabase';

const clean = (n) => n.replace(/[^\w.-]/g, '_');

export default function Order() {
  const { t, lang } = useLang();
  const [service, setService] = useState(SERVICES[0].id);
  const [state, setState] = useState('idle');
  useEffect(() => {
    const s = new URLSearchParams(window.location.search).get('service');
    if (SERVICES.some((x) => x.id === s)) setService(s);
  }, []);

  async function submit(e) {
    e.preventDefault();
    const form = e.currentTarget;
    const v = Object.fromEntries(new FormData(form));
    setState('sending');
    try {
      const sb = getSb();
      const id = crypto.randomUUID();
      const files = [...form.logo.files, ...form.refs.files];
      const paths = [];
      for (const [i, f] of files.entries()) {
        const path = `${id}/${i}-${clean(f.name)}`;
        const { error } = await sb.storage.from('order-files').upload(path, f);
        if (error) throw error;
        paths.push(path);
      }
      const { error } = await sb.from('orders').insert({
        id, name: v.name, brand: v.brand, activity: v.activity, service: v.service,
        description: v.description, colors: v.colors, features: v.features,
        reference_url: v.reference_url, contact: v.contact, budget: v.budget,
        deadline: v.deadline || null, files: paths,
      });
      if (error) throw error;
      form.reset();
      setState('ok');
    } catch { setState('error'); }
  }

  const f = t.f;
  const L = ({ k, children }) => <label>{f[k]}{children}</label>;
  return (
    <div className="page">
      <h2>{t.order}</h2>
      <form className="glass" onSubmit={submit}>
        <L k="name"><input name="name" required /></L>
        <L k="brand"><input name="brand" required /></L>
        <L k="activity"><input name="activity" /></L>
        <L k="service">
          <select name="service" value={service} onChange={(e) => setService(e.target.value)}>
            {SERVICES.map((s) => <option key={s.id} value={s.id}>{lang === 'ar' ? s.ar : s.en}</option>)}
          </select>
        </L>
        <L k="description"><textarea name="description" rows={4} /></L>
        <L k="colors"><input name="colors" /></L>
        <L k="features"><textarea name="features" rows={3} /></L>
        <L k="reference_url"><input name="reference_url" type="url" /></L>
        <L k="contact"><input name="contact" required /></L>
        <L k="budget"><input name="budget" /></L>
        <L k="deadline"><input name="deadline" type="date" /></L>
        <L k="logo"><input name="logo" type="file" accept="image/*" /></L>
        <L k="refs"><input name="refs" type="file" accept="image/*" multiple /></L>
        <button className="btn" disabled={state === 'sending'}>{state === 'sending' ? t.sending : t.send}</button>
        {state === 'ok' && <p className="msg ok" role="status">{t.ok}</p>}
        {state === 'error' && <p className="msg bad" role="alert">{t.err}</p>}
      </form>
    </div>
  );
}
