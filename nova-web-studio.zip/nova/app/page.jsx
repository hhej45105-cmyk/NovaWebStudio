'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useLang } from '@/lib/i18n';
import { SERVICES } from '@/lib/services';
import { CONFIG } from '@/lib/config';
import { getSb } from '@/lib/supabase';

export default function Home() {
  const { t, lang } = useLang();
  const [works, setWorks] = useState([]);
  const [prices, setPrices] = useState({});
  useEffect(() => {
    const sb = getSb();
    sb.from('service_prices').select('service,price').then(({ data }) => setPrices(Object.fromEntries((data || []).map((r) => [r.service, r.price]))));
    sb.from('portfolio').select('id,title,category,url,image_url').order('created_at', { ascending: false })
      .then(({ data }) => setWorks(data || []));
  }, []);

  return (
    <>
      <section className="hero">
        <h1>{t.title}</h1>
        <p>{t.sub}</p>
        <div className="row">
          <Link className="btn" href="/order">{t.order}</Link>
          <Link className="btn ghost" href="/#work">{t.works}</Link>
        </div>
      </section>

      <section id="services">
        <h2>{t.services}</h2>
        <div className="grid">
          {SERVICES.map((s) => (
            <article key={s.id} className="glass card">
              <span className="ico" aria-hidden>{s.icon}</span>
              <h3><Link href={`/services/${s.id}`}>{lang === 'ar' ? s.ar : s.en}</Link></h3>
              <p>{lang === 'ar' ? s.dAr : s.dEn}</p>
              {prices[s.id] && <p className="price">{t.priceFrom} {prices[s.id]}</p>}
              <Link href={`/services/${s.id}`}>{t.details}</Link>
              <Link className="btn ghost" href={`/order?service=${s.id}`}>{t.orderService}</Link>
            </article>
          ))}
        </div>
      </section>

      <section id="work">
        <h2>{t.portfolio}</h2>
        {works.length === 0 ? <p className="msg glass">{t.noWorks}</p> : (
          <div className="grid">
            {works.map((w) => (
              <article key={w.id} className="glass card">
                {w.image_url && <img src={w.image_url} alt={w.title} loading="lazy" style={{ width: '100%', borderRadius: 12 }} />}
                <h3>{w.title}</h3><p>{SERVICES.find((x) => x.id === w.category)?.[lang] || w.category}</p>
                {w.url && <a className="btn ghost" href={w.url} target="_blank" rel="noreferrer">{t.view}</a>}
              </article>
            ))}
          </div>
        )}
      </section>

      <section id="about">
        <h2>{t.about}</h2>
        <p className="glass card">{t.aboutText}</p>
      </section>

      <section id="faq">
        <h2>{t.faq}</h2>
        {t.faqList.map(([q, a]) => <details key={q} className="glass"><summary>{q}</summary><p>{a}</p></details>)}
      </section>

      <section id="contact">
        <h2>{t.contact}</h2>
        <div className="row">
          <a className="btn" href={CONFIG.discord} target="_blank" rel="noreferrer">Discord</a>
          {CONFIG.whatsapp && <a className="btn" href={CONFIG.whatsapp} target="_blank" rel="noreferrer">WhatsApp</a>}
          <a className="btn ghost" href={`mailto:${CONFIG.email}`}>{CONFIG.email}</a>
        </div>
      </section>
    </>
  );
}
