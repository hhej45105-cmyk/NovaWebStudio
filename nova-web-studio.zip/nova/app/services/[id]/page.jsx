'use client';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useLang } from '@/lib/i18n';
import { SERVICES } from '@/lib/services';
import { getSb } from '@/lib/supabase';

export default function ServicePage() {
  const { id } = useParams();
  const { t, lang } = useLang();
  const s = SERVICES.find((x) => x.id === id);
  const [works, setWorks] = useState([]);
  const [price, setPrice] = useState(null);
  useEffect(() => {
    const sb = getSb();
    sb.from('portfolio').select('id,title,url,image_url').eq('category', id).then(({ data }) => setWorks(data || []));
    sb.from('service_prices').select('price').eq('service', id).maybeSingle().then(({ data }) => setPrice(data?.price || null));
  }, [id]);
  if (!s) return <div className="page"><h2>404</h2><Link className="btn" href="/">{t.home}</Link></div>;
  return (
    <div className="page">
      <div className="glass card" style={{ padding: '2rem' }}>
        <span className="ico" aria-hidden>{s.icon}</span>
        <h2>{lang === 'ar' ? s.ar : s.en}</h2>
        <p>{lang === 'ar' ? s.dAr : s.dEn}</p>
        {price && <p><b>{t.priceFrom} {price}</b></p>}
        <h3>{t.features}</h3>
        <ul>{t.featList.map((f) => <li key={f}>{f}</li>)}</ul>
        <div><Link className="btn" href={`/order?service=${s.id}`}>{t.orderThis}</Link></div>
      </div>
      <h2 style={{ marginTop: '3rem' }}>{t.similar}</h2>
      {works.length === 0 ? <p className="msg glass">{t.noWorks}</p> : (
        <div className="grid">
          {works.map((w) => (
            <article key={w.id} className="glass card">
              {w.image_url && <img src={w.image_url} alt={w.title} loading="lazy" style={{ width: '100%', borderRadius: 12 }} />}
              <h3>{w.title}</h3>
              {w.url && <a className="btn ghost" href={w.url} target="_blank" rel="noreferrer">{t.view}</a>}
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
