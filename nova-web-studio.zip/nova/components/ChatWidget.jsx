'use client';
import { useEffect, useRef, useState } from 'react';
import { useLang } from '@/lib/i18n';
import { getSb } from '@/lib/supabase';

export default function ChatWidget() {
  const { t, lang } = useLang();
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState('ai');
  const [ai, setAi] = useState([]);
  const [team, setTeam] = useState([]);
  const [uid, setUid] = useState(null);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const end = useRef(null);

  useEffect(() => {
    if (!open || tab !== 'team' || uid) return;
    (async () => {
      const sb = getSb();
      let { data: { session } } = await sb.auth.getSession();
      if (!session) ({ data: { session } } = await sb.auth.signInAnonymously());
      if (session) setUid(session.user.id);
    })();
  }, [open, tab, uid]);

  useEffect(() => {
    if (!uid) return;
    const sb = getSb();
    sb.from('messages').select('*').eq('thread', uid).order('created_at').then(({ data }) => setTeam(data || []));
    const ch = sb.channel('m-' + uid).on('postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'messages', filter: `thread=eq.${uid}` },
      (p) => setTeam((m) => (m.some((x) => x.id === p.new.id) ? m : [...m, p.new]))).subscribe();
    return () => { sb.removeChannel(ch); };
  }, [uid]);

  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }); }, [ai, team, open, tab]);

  async function send(e) {
    e.preventDefault();
    const body = text.trim();
    if (!body || busy) return;
    setText('');
    if (tab === 'team') {
      if (uid) await getSb().from('messages').insert({ thread: uid, sender: 'client', body });
      return;
    }
    const next = [...ai, { role: 'user', content: body }];
    setAi(next); setBusy(true);
    try {
      const r = await fetch('/api/assistant', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ messages: next, lang }) });
      const d = await r.json();
      setAi([...next, { role: 'assistant', content: d.reply || t.aiErr }]);
    } catch { setAi([...next, { role: 'assistant', content: t.aiErr }]); }
    setBusy(false);
  }

  const list = tab === 'ai'
    ? [{ role: 'assistant', content: t.aiHello }, ...ai].map((m, i) => ({ id: i, me: m.role === 'user', body: m.content }))
    : [{ id: 'h', me: false, body: t.teamHello }, ...team.map((m) => ({ id: m.id, me: m.sender === 'client', body: m.body }))];

  return (
    <>
      <button className="btn chat-fab" onClick={() => setOpen(!open)} aria-expanded={open}>{open ? '×' : t.chat}</button>
      {open && (
        <div className="glass chat-box">
          <div className="row" style={{ gap: '.5rem' }}>
            <button className={tab === 'ai' ? 'btn' : 'btn ghost'} onClick={() => setTab('ai')}>{t.aiTab}</button>
            <button className={tab === 'team' ? 'btn' : 'btn ghost'} onClick={() => setTab('team')}>{t.teamTab}</button>
          </div>
          <div className="chat-log">
            {list.map((m) => <p key={m.id} className={m.me ? 'bubble me' : 'bubble'}>{m.body}</p>)}
            {busy && <p className="bubble">…</p>}
            <div ref={end} />
          </div>
          <form className="row" style={{ flexWrap: 'nowrap' }} onSubmit={send}>
            <input value={text} onChange={(e) => setText(e.target.value)} placeholder={t.ph} style={{ flex: 1, minWidth: 0 }} maxLength={1500} />
            <button className="btn">{t.sendMsg}</button>
          </form>
        </div>
      )}
    </>
  );
}
