'use client';
import { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Stars } from '@react-three/drei';

function Shape({ pos, scale = 1, speed = 0.25, children }) {
  const ref = useRef();
  useFrame((_, d) => { ref.current.rotation.x += d * speed; ref.current.rotation.y += d * speed * 0.8; });
  return (
    <Float speed={1.5} floatIntensity={2.5} position={pos}>
      <mesh ref={ref} scale={scale}>
        {children}
        <meshStandardMaterial color="#061230" emissive="#1e6bff" emissiveIntensity={1.1} wireframe />
      </mesh>
    </Float>
  );
}

function Rig() {
  useFrame(({ camera, pointer }) => {
    camera.position.x += (pointer.x * 1.5 - camera.position.x) * 0.04;
    camera.position.y += (pointer.y * 1.0 - camera.position.y) * 0.04;
    camera.lookAt(0, 0, 0);
  });
  return null;
}

export default function Scene3D({ intro }) {
  return (
    <Canvas camera={{ position: [0, 0, 10], fov: 55 }} dpr={[1, 1.5]}>
      <ambientLight intensity={0.3} />
      <pointLight position={[6, 6, 6]} color="#38bdf8" intensity={80} />
      <Stars radius={70} count={1800} factor={3} fade speed={1} />
      <Shape pos={intro ? [0, 0, 0] : [3.5, 0.5, -3]} scale={intro ? 2.2 : 1.3}><torusKnotGeometry args={[1, 0.3, 160, 20]} /></Shape>
      <Shape pos={[-5, 2.5, -2]} speed={0.4}><icosahedronGeometry args={[1, 0]} /></Shape>
      <Shape pos={[-3.5, -2.5, 0]} scale={0.8} speed={0.5}><octahedronGeometry args={[1, 0]} /></Shape>
      <Shape pos={[5.5, -2.5, -1]} scale={1.1}><torusGeometry args={[1, 0.25, 16, 48]} /></Shape>
      <Shape pos={[0, 3.6, -4]} scale={0.9} speed={0.35}><dodecahedronGeometry args={[1, 0]} /></Shape>
      <Rig />
    </Canvas>
  );
}
