'use client';
import dynamic from 'next/dynamic';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { LangProvider, useLang } from '@/lib/i18n';
import ChatWidget from './ChatWidget';

const Scene = dynamic(() => import('./Scene3D'), { ssr: false });

function Inner({ children }) {
  const { t, lang, setLang } = useLang();
  const [entered, setEntered] = useState(null);
  useEffect(() => { setEntered(sessionStorage.getItem('nws-in') === '1'); }, []);
  const enter = () => { sessionStorage.setItem('nws-in', '1'); setEntered(true); };

  return (
    <>
      <div className="bg3d" aria-hidden><Scene intro={entered === false} /></div>
      {entered === false && (
        <main className="intro" onClick={enter}>
          <h1 className="wordmark big">Nova Web Studio</h1>
          <button className="btn" onClick={enter}>{t.enter}</button>
        </main>
      )}
      {entered && (
        <>
          <header className="nav glass">
            <Link href="/" className="wordmark">Nova Web Studio</Link>
            <nav>
              <Link href="/#services">{t.services}</Link>
              <Link href="/#work">{t.portfolio}</Link>
              <Link href="/#contact">{t.contact}</Link>
              <button className="lang" onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}>{lang === 'ar' ? 'EN' : 'ع'}</button>
            </nav>
          </header>
          {children}
          <ChatWidget />
        </>
      )}
    </>
  );
}

export default function Shell({ children }) {
  return <LangProvider><Inner>{children}</Inner></LangProvider>;
}
