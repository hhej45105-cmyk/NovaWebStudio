module.exports = { transpilePackages: ['three'] };
