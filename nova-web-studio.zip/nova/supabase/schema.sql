-- شغّل هذا الملف كاملاً في Supabase > SQL Editor
create table admin_emails (email text primary key);
insert into admin_emails (email) values ('ahmedkhaleduu3@gmail.com'), ('hhej45105@gmail.com');
create table orders (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null, brand text not null, activity text,
  service text not null, description text, colors text, features text,
  reference_url text, contact text not null, budget text, deadline date,
  files text[] not null default '{}',
  status text not null default 'new' check (status in ('new','review','in_progress','done','rejected')),
  delivered_url text
);
create index orders_status_created_idx on orders (status, created_at desc);
create table portfolio (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  title text not null, category text, url text, image_url text
);
alter table admin_emails enable row level security;
alter table orders enable row level security;
alter table portfolio enable row level security;

create function is_admin() returns boolean language sql security definer stable set search_path = public as
$$ select exists (select 1 from admin_emails where email = lower((select auth.jwt() ->> 'email'))) $$;

create policy orders_insert on orders for insert to anon, authenticated
  with check (status = 'new' and delivered_url is null);
create policy orders_admin on orders for all to authenticated
  using (is_admin()) with check (is_admin());
create policy portfolio_read on portfolio for select to anon, authenticated using (true);
create policy portfolio_admin on portfolio for all to authenticated
  using (is_admin()) with check (is_admin());

insert into storage.buckets (id, name, public) values ('order-files', 'order-files', false);
create policy files_upload on storage.objects for insert to anon, authenticated
  with check (bucket_id = 'order-files');
create policy files_admin_read on storage.objects for select to authenticated
  using (bucket_id = 'order-files' and is_admin());

-- الأسعار والدردشة المباشرة
create table service_prices (service text primary key, price text not null);
create table messages (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  thread uuid not null,
  sender text not null check (sender in ('client','admin')),
  body text not null check (length(body) between 1 and 2000)
);
create index messages_thread_idx on messages (thread, created_at);
alter table service_prices enable row level security;
alter table messages enable row level security;
create policy prices_read on service_prices for select to anon, authenticated using (true);
create policy prices_admin on service_prices for all to authenticated using (is_admin()) with check (is_admin());
create policy msg_client_read on messages for select to authenticated using (thread = (select auth.uid()));
create policy msg_client_send on messages for insert to authenticated
  with check (thread = (select auth.uid()) and sender = 'client');
create policy msg_admin on messages for all to authenticated using (is_admin()) with check (is_admin());
alter publication supabase_realtime add table messages, orders;
